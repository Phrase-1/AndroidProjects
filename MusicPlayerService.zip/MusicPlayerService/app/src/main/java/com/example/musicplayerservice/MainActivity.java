package com.example.musicplayerservice;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private Button playBt;
    private Button pauseBt;
    private Button stopBt;
    private MusicService.PlayerBinder Binder;

/*在Activity中除了一些控制用的控件之外, 最主要的是一个类型为MusicService.MyBinder的成员变量, 和一个类型为ServiceConnection的成员变量.
其中ServiceConnection在启动服务时传入, 在它的方法中我们获取Binder, 并赋值给Binder. 注意启动服务是调用bindService.*/

    /* 在MainActivity里写：
     * 通过绑定方式的启动服务
     * 第一步:创建好Service之后写一个继承自Binder的内部类,在该类中写好操作Service的方法
     * 第二步:定义一个Binder对象
     * 第三步:在onBind生命周期中,将该Binder对象返回
     *
     */

    private ServiceConnection mConnection = new ServiceConnection() {   //创建实例 用来接收onbind方法返回的。
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {

            Binder = (MusicService.PlayerBinder) service;//根据查得资料照着写的语句
            //通过按键返回值，判断状态为播放还是停止；此时返回值只有两个可以用bool
            boolean a = Binder.IsPlay();
            if (a == true) {
                playBt.setEnabled(true);
                pauseBt.setEnabled(false);
                stopBt.setEnabled(false);
            } else {
                playBt.setEnabled(false);
                pauseBt.setEnabled(true);
                stopBt.setEnabled(true);
            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            Binder = null;
        }
    };

        @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        playBt = (Button) findViewById(R.id.playBt);
        pauseBt = (Button) findViewById(R.id.pauseBt);
        stopBt = (Button) findViewById(R.id.stopBt);
        playBt.setOnClickListener(this);
        pauseBt.setOnClickListener(this);
        stopBt.setOnClickListener(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.playBt:
                Intent t1 = new Intent(this, MusicService.class);
                t1.putExtra("op", 1);
                startService(t1);
                playBt.setEnabled(false);
                pauseBt.setEnabled(true);
                stopBt.setEnabled(true);
                break;
            case R.id.pauseBt:
                Intent t2 = new Intent(this, MusicService.class);
                t2.putExtra("op", 2);
                startService(t2);
                playBt.setEnabled(true);
                pauseBt.setEnabled(false);
                stopBt.setEnabled(true);
                break;
            case R.id.stopBt:
                Intent t3 = new Intent(this, MusicService.class);
                stopService(t3);
                playBt.setEnabled(true);
                pauseBt.setEnabled(false);
                stopBt.setEnabled(false);
                break;
        }
    }



}
