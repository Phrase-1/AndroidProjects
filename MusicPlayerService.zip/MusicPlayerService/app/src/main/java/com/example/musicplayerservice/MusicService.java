package com.example.musicplayerservice;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;

/**
 * Created by LAB on 2019/6/10.
 */

public class MusicService extends Service {

    /*
     * 第一步:注册
     * 第二步:建立内部类  Binder  为了绑定客户端与服务端
     * 第三步:在Service的onBind方法中  返回Binder对象
     */
    private  IBinder binder = new PlayerBinder();

    private MediaPlayer mp;

    @Nullable
    @Override
    /*
     *我们在onBind生命周期中,返回我们自己写的Binder对象
     * 来讲服务通过Binder对象连接取来
     */
    public IBinder onBind(Intent intent) {

        return binder;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("MusicService", "onCreate");
        mp = MediaPlayer.create(this, R.raw.m2);
        mp.setLooping(true);
    }


     /*
       自定义的内部类,继承Binder
       在该内部类里,我们写对服务进行操作的方法
     */

    public class PlayerBinder extends Binder{
        boolean IsPlay(){
            if (mp.isPlaying() == true)
            {
                return false;
            }
            else
                return true;
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("MusicService", "onStartCommand");
        int op = intent.getIntExtra("op", 1);
        switch (op){
            case 1:
                mp.start();
                break;
            case 2:
                mp.pause();
                break;
        }
        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        Log.i("MusicService", "onDestroy");
        super.onDestroy();
        mp.release();
    }


}
