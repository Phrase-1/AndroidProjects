package com.example.daotest;

class ThreePartNavigation {
}
