package com.example.officemanager.Supply;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.officemanager.R;

public class AddActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);
        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();
        String name = bundle.getString("name");
        String number = bundle.getString("number");
        String condition = bundle.getString("condition");
        TextView tv_name = (TextView)findViewById(R.id.name);
        TextView tv_number = (TextView)findViewById(R.id.number);
        TextView tv_condition = (TextView)findViewById(R.id.condition);
        tv_name.setText(name);
        tv_number.setText(number);
        tv_condition.setText(condition);

    }
}
