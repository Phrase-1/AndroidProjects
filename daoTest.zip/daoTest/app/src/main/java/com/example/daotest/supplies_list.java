package com.example.officemanager.Supply;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.example.officemanager.Schdule.ScheduleNote;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;

public class supplies_list extends AppCompatActivity implements AdapterView.OnClickListener {
    private Button addBt;
    private Button searchBt;
    private Button selectBt;
    private Button deleteBt;
    private ListView listView;
    private ArrayList<Supply> data;
    private DbHelper helper;
    private Dao<Supply, Integer> sDao;
    private SupplyAdapter supplyAdapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_supplies_list);

        addBt = (Button) findViewById(R.id.bn_add_id);
        addBt.setOnClickListener(this);
        searchBt = (Button) findViewById(R.id.bn_search_id);
        searchBt.setOnClickListener(this);
        selectBt = (Button) findViewById(R.id.bn_select_id);
        selectBt.setOnClickListener(this);
        deleteBt = (Button) findViewById(R.id.bn_delete_id);
        deleteBt.setOnClickListener(this);
        listView = findViewById(R.id.supListLv);



        try {
             helper = new DbHelper(this);
             sDao = helper.getDao(Supply.class);
             int a = 0;
             data = (ArrayList<Supply>) sDao.queryForAll();//查询关键语句


        } catch (SQLException e) {
            e.printStackTrace();
        }
           supplyAdapter = new SupplyAdapter(data,this);
           listView.setAdapter(supplyAdapter);//将读到的数据显示到listview上面
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.bn_add_id:
                Intent i = new Intent(supplies_list.this, com.example.officemanager.Supply.AddSupplyActivity.class);
                startActivity(i);

        }
    }
}
