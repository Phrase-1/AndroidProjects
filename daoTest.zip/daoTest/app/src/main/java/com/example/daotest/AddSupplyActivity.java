package com.example.officemanager.Supply;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.example.officemanager.Schdule.ScheduleNote;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;

public class AddSupplyActivity extends AppCompatActivity {
    private DbHelper helper;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.add_supply);
        Button btn = (Button) findViewById(R.id.bt_bc);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name=((EditText)findViewById(R.id.et_name)).getText().toString();//获取信息
                int number = Integer.parseInt(((EditText)findViewById(R.id.et_number)).getText().toString());
                String condition=((EditText)findViewById(R.id.et_condition)).getText().toString();
                if(!"".equals(name)&&!"".equals(number)&&!"".equals(condition)){
                    Supply sup = new Supply(name,number,condition);
                    Intent intent = new Intent(AddSupplyActivity.this, com.example.officemanager.Supply.AddActivity.class);
                    Bundle bundle = new Bundle();
                    bundle.putCharSequence("name",name);
                    bundle.putInt("number",number);
                    bundle.putCharSequence("condition",condition);
                    intent.putExtras(bundle);
                    try {
                        Dao<Supply,String> sDao = helper.getDao(Supply.class);//数据连接对象
                        sDao.create(sup);//插入语句
                        Toast.makeText(AddSupplyActivity.this,"数据入库！",Toast.LENGTH_SHORT).show();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    startActivity(intent);
                }
                else {
                    Toast.makeText(AddSupplyActivity.this,"请将物品信息填写完整！",Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}
