package com.example.officemanager.Supply;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.officemanager.R;
import com.example.officemanager.Supply.Supply;

import java.util.ArrayList;

public class SupplyAdapter extends BaseAdapter {
    private ArrayList<Supply> data;
    protected Activity activity;
    private Activity view;
    LinearLayout layout;



    public SupplyAdapter(ArrayList < Supply > data, Activity activity) {
        this.data = data;
        this.activity = activity;
    }

    @Override
    public int getCount () {
        return data.size();
    }

    @Override
    public Object getItem ( int position){
        return null;
    }

    @Override
    public long getItemId ( int position){
        return 0;
    }

    @Override
    public View getView ( int position, View convertView, ViewGroup parent) {
        Supply supply = data.get(position);
        LinearLayout layout = null;
        TextView nameView = (TextView) layout.findViewById(R.id.name_list_id);
        TextView numberView = (TextView) layout.findViewById(R.id.number_list_id);
        TextView conditionView = (TextView) layout.findViewById(R.id.condition_list_id);
        CheckBox checkBox1 = layout.findViewById(R.id.checkbox_id);
        if(convertView == null){
            LayoutInflater li = activity.getLayoutInflater();
            layout = (LinearLayout) li.inflate(R.layout.supply_item,null);
        }else{
            layout = (LinearLayout) convertView;
        }

        nameView.setText(supply.getName());
        numberView.setText(supply.getNumber());
        conditionView.setText(supply.getCondition());
        checkBox1.setChecked(false);


        return layout;

//            CheckBox.onClickListener checkboxLinstener = new CheckBox.onClickListener();
    }


}
