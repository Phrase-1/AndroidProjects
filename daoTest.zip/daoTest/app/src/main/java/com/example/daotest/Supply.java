package com.example.officemanager.Supply;

import com.j256.ormlite.field.DatabaseField;

import java.util.Date;

public class Supply {

    @DatabaseField(columnName = "number")
    private int number;
    @DatabaseField(id = true)
    private int id;
    @DatabaseField(canBeNull = false,columnName = "creatDate")
    private String name;

    @DatabaseField(columnName = "condition")
    private String condition;

    private boolean selected;

    public Supply(String name, int number, String condition) {//int id,
        this.number = number;
        this.id = id;
        this.name = name;
        this.condition = condition;
        selected = false;


    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

//    public int getId() {
//        return id;
//    }
//
//    public void setId(int id) {
//        this.id = id;
//    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
}
