package com.example.myapplication;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by LAB on 2019/6/13.
 */

public class DbOpenHelper extends SQLiteOpenHelper{
    private DbOpenHelper dbOpenHelper;
    private static final int VERSION = 1;//版本
    private static final String DB_NAME = "Supply.db";//数据库名
    public static final String SUPPLY_TABLE = "supply";
    public static final String NUMBER ="number";//表中的列名
    public static final String NAME = "name";
    public static final String CONDITION = "condition";
    public static final String TYPE = "type";
    private static final String CREATE_TABLE = "create table"
            + SUPPLY_TABLE +"("+NUMBER+" Integer primary key autoincrement,"+NAME+
            " text not null,"+CONDITION+" text not null,"+TYPE+"text not null )";

    public DbOpenHelper(Context context) {
        super(context, DB_NAME, null, VERSION);

    }

    public DbOpenHelper(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    //数据库第一次被创建时调用
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_TABLE);
    }

    //版本升级时被调用
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
    /**
     * 增，用insert向数据库中插入数据
     */
    public void add(Supply p) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();//SQLiteOpenHelper方法中读写
        ContentValues values = new ContentValues();
        values.put(dbOpenHelper.NUMBER, p.getnumber());
        values.put(dbOpenHelper.NAME, p.getName());
        values.put(dbOpenHelper.CONDITION, p.getcondition());
        values.put(dbOpenHelper.TYPE,p.gettype());
        db.insert(dbOpenHelper.SUPPLY_TABLE, null, values);
    }

    /**
     * 删，通过number删除数据
     */
    public void delete(int number) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        db.delete(dbOpenHelper.SUPPLY_TABLE, dbOpenHelper.NUMBER + "=?", new String[]
                {String.valueOf(number)});
    }

    /**
     * 改，修改指定number的数据
     */
    public void updata(Supply p) {
        SQLiteDatabase db = dbOpenHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(dbOpenHelper.NUMBER, p.getnumber());
        values.put(dbOpenHelper.NAME, p.getName());
        db.update(dbOpenHelper.SUPPLY_TABLE, values, dbOpenHelper.NUMBER + "=?", new String[]
                {String.valueOf(p.getnumber())});
    }

    /**
     * 查，查询表中所有的数据
     */
    public List<Supply> find() {
        List<Supply> Supplys = null;
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.query(dbOpenHelper.SUPPLY_TABLE, null, null, null, null, null, null);
        if(cursor != null){
            Supplys = new ArrayList<Supply>();
            while(cursor.moveToNext()){
                Supply Supply = new Supply();
                int NUMBER = cursor.getInt(cursor.getColumnIndex(dbOpenHelper.NUMBER));
                String name = cursor.getString(cursor.getColumnIndex(dbOpenHelper.NAME));
                Supply.setnumber(NUMBER);
                Supply.setName(name);
                Supplys.add(Supply);
            }
        }
        return Supplys;
    }

    public Supply findById(int id) {
        return null;
    }

    /**
     * 查询指定number的数据
     */
    public Supply findBynumber(int number) {
        SQLiteDatabase db = dbOpenHelper.getReadableDatabase();
        Cursor cursor = db.query(dbOpenHelper.SUPPLY_TABLE, null, dbOpenHelper.NUMBER + "=?", new
                String[]{String.valueOf(number)}, null, null, null);
        Supply Supply = null;
        if(cursor != null && cursor.moveToFirst()){
            Supply = new Supply();
            int NUMBER = cursor.getInt(cursor.getColumnIndex(dbOpenHelper.NUMBER));
            String name = cursor.getString(cursor.getColumnIndex(dbOpenHelper.NAME));
            Supply.setnumber(NUMBER);
            Supply.setName(name);
        }
        return Supply;
    }
}


//建立数据库代码：DbOpenHelper.java
