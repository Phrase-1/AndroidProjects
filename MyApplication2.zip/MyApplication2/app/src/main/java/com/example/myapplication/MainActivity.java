package com.example.myapplication;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;

import com.example.myapplication.R;

public class MainActivity extends AppCompatActivity implements AdapterView.OnClickListener{
    private Button supplies_list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        supplies_list = (Button) findViewById(R.id.bn_supplies_list_id);
        supplies_list.setOnClickListener(this);
    }
    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.bn_supplies_list_id:
                Intent i = new Intent(MainActivity.this, SQLOperateImpl.class);
                startActivity(i);
        }


    }
}
