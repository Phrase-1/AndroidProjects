package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ListView;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.lab.myapplication.Supply;
import com.example.lab.myapplication.SupplyAdapter;

public class SQLOperateImpl extends AppCompatActivity implements SQLOperate, View.OnClickListener {
    private Button addBt;
    private Button searchBt;
    private Button selectBt;
    private Button deleteBt;
    private ListView supplyListLv;
    private ArrayList<Supply> data;
    private SupplyAdapter supplyAdapter;
    private DbOpenHelper dbOpenHelper;


    public SQLOperateImpl(Context context) {
        dbOpenHelper = new DbOpenHelper(context);
    }

    public SQLOperateImpl() {
    }


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqloperate_impl);
        int a = 0;
//        Log.i("log","1212");

        initView();

        addBt.setOnClickListener(this);
        searchBt.setOnClickListener(this);
        selectBt.setOnClickListener(this);
        deleteBt.setOnClickListener(this);
    }
    public void initView(){
        addBt = (Button) findViewById(R.id.bn_add_id);
        searchBt = (Button) findViewById(R.id.bn_search_id);
        selectBt = (Button) findViewById(R.id.bn_select_id);
        deleteBt = (Button) findViewById(R.id.bn_delete_id);
        supplyListLv = (ListView) findViewById(R.id.supplyListLv);
    }

    public void  onAction(View v){
        DbOpenHelper dbOpenHelper = new DbOpenHelper(this);
        switch (v.getId()){
            case R.id.bn_search_id:

                dbOpenHelper.findBynumber(n);
                break;
            case R.id.bn_add_id:
                Supply
                dbOpenHelper.add();
                break;
            case R.id.bn_select_id:
                break;
            case R.id.bn_delete_id:
                break;
        }



    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void add(Supply p) {

    }

    @Override
    public void delete(int id) {

    }

    @Override
    public void updata(Supply p) {

    }

    @Override
    public List<Supply> find() {
        return null;
    }

    @Override
    public Supply findById(int id) {
        return null;
    }
}