package com.example.myapplication;

class SupplyAdapter {
}
