package com.example.myapplication;
/**
 * Created by LAB on 2019/6/13.
 */

public class Supply {

    private int number;
    private String name;
    private String condition;
    private  String type;


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return "Supply [number=" + number+ ", name=" + name + ",condition "+condition+"]";
    }

    public Supply() {
        super();
    }

    public Supply(int number, String name) {
        super();
        this.number = number;
        this.name = name;
    }

    public void setnumber(int number) {
        this.number = number;
    }

    public int getnumber() {
        return number;
    }

    public String gettype(){
        return type;
    }



    public void gettype(String type){
        this.type = type;
    }


    public String getcondition() {
        return condition;
    }
}


