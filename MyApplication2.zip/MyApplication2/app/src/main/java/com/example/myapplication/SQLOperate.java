package com.example.myapplication;
import java.util.List;

/**
 * Created by LAB on 2019/6/13.
 */

interface SQLOperate {

    //接口类
    public void add(Supply p);
    public void delete(int id);
    public void updata(Supply p);
    public List<Supply> find();
    public Supply findById(int id);

}

