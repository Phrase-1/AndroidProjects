package com.example.sqllitepractice;

import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.field.ForeignCollectionField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by LAB on 2019/5/23.
 */
@DatabaseTable(tableName = "departments")
public class Department {
    @DatabaseField(id =true)
    private int id;
    @DatabaseField
    private String name;

    @ForeignCollectionField
    ForeignCollection<Student> students;

    public Department(){
    }

    public Department(int id, String name) {
        this.id = id;
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
