package com.example.sqllitepractice;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

/**
 * Created by LAB on 2019/5/20.
 */

@DatabaseTable(tableName = "students")
public class Student {

    @DatabaseField(id = true)
    private int id;
    @DatabaseField(canBeNull = false)
    private String no;
    @DatabaseField
    private String name;
    @DatabaseField
    private boolean sex;

    @DatabaseField(foreign = true, foreignColumnName = "id", columnName = "did")
    private Department department;

    public Student(){
    }

    public Student(int id, String no, String name, boolean sex, Department department) {
        this.id = id;
        this.no = no;
        this.name = name;
        this.sex = sex;
        this.department = department;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }
}
