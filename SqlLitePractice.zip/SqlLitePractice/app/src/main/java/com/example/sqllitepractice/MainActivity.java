package com.example.sqllitepractice;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button addBt = (Button) findViewById(R.id.AddBt);
        Button queryBt = (Button) findViewById(R.id.QueryBt);

        addBt.setOnClickListener(this);
        queryBt.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.AddBt:
                DbHelper helper = new DbHelper(this);

                try {
                    Dao<Student, Integer> sdao = helper.getDao(Student.class);
                    Dao<Department, Integer> dDao = helper.getDao(Department.class);
                    Department d = new Department(1,"CS");
                    Student s1 = new Student(1,"1","www",false,d);
                    sdao.create(s1);

                    int a = 10;

                } catch (SQLException e) {
                    e.printStackTrace();
                }
        }
    }
}
