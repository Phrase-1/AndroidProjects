package com.example.officemanager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.officemanager.Login.Account;
import com.example.officemanager.Login.RegisterActivity;
import com.j256.ormlite.dao.Dao;

import java.util.List;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener,View.OnLongClickListener, AdapterView.OnItemLongClickListener {
    public EditText etAc;
    public EditText etPw;
    private Button btDl;
    private Button btZc;
    public String user;
    public String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bingID();

        initEvent();             //为控件设置事件

    }

    private void bingID() {
        etAc = findViewById(R.id.etAc);
        etPw = findViewById(R.id.etPw);
        btDl = findViewById(R.id.btDl);
        btZc = findViewById(R.id.btZc);

    }
    private void initEvent() {
        btDl.setOnClickListener(this);
        btZc.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        user=etAc.getText().toString();
        password=etPw.getText().toString();
        switch (v.getId()) {
            case R.id.btZc:
                Intent t1 = new Intent(this, RegisterActivity.class);
                startActivity(t1);
                break;
            case R.id.btDl:
                Judget();

                break;
        }
    }
    public void Judget(){                                              //判断输入用户名是否重复以及密码输入是否一致

        DbHelper helper = new DbHelper(this);
        try{
            Dao<Account, Integer> dao = helper.getDao(Account.class);
            List<Account> account2=dao.queryBuilder().where().eq("username",user).and().eq("password",password).query();
            //核对姓名与密码
            if(account2.isEmpty()==true){

                Toast.makeText(this, "用户名或密码输入不正确请检查后重新输入", Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this, "登陆成功", Toast.LENGTH_SHORT).show();
                Intent t2=new Intent(this, ThreePartNavigation.class);
                startActivity(t2);
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public boolean onLongClick(View v) {
        return false;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }
}
