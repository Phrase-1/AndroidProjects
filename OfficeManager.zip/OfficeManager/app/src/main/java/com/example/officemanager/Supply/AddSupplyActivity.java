package com.example.officemanager.Supply;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officemanager.R;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddSupplyActivity extends AppCompatActivity implements View.OnClickListener {
    //private static final String TAG = "AddSupplyActivity";
    //private final static int DATE_DIALOG = 1;
    private static final int DATE_PICKER_ID = 1;
    private TextView idText;
    private EditText nameText;
    private EditText numberText;
    private EditText phoneText;
    private EditText dataText;
    private RadioGroup group;
    private RadioButton button1;
    private RadioButton button2;
    private CheckBox box1;
    private CheckBox box2;
    private CheckBox box3;
    private Button restoreButton;
    private String attribute;
    private Button resetButton;
    private Long supply_id;
    private SupplyDao dao;
    private boolean isAdd = true;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_supply);
        idText = (TextView) findViewById(R.id.tv_stu_id);
        nameText = (EditText) findViewById(R.id.et_name);
        numberText = (EditText) findViewById(R.id.et_number);
        button1 = (RadioButton) findViewById(R.id.rb_attribute_female);
        button2 = (RadioButton) findViewById(R.id.rb_attribute_male);
        phoneText = (EditText) findViewById(R.id.et_phone);
        dataText = (EditText) findViewById(R.id.et_usedate);
        group = (RadioGroup) findViewById(R.id.rg_attribute);
        box1 = (CheckBox) findViewById(R.id.box1);
        box2 = (CheckBox) findViewById(R.id.box2);
        box3 = (CheckBox) findViewById(R.id.box3);
        restoreButton = (Button) findViewById(R.id.btn_save);
        resetButton = (Button) findViewById(R.id.btn_clear);
        dao = new SupplyDao(new SupplyDBHelper(this)); // 设置监听 78
        restoreButton.setOnClickListener(this);
        resetButton.setOnClickListener(this);
        dataText.setOnClickListener(this);
        checkIsAddSupply();
    }

    private void checkIsAddSupply() {
        Intent intent = getIntent();
        Serializable serial = intent.getSerializableExtra(TableContanst.SUPPLY_TABLE);
        if (serial == null) {
            isAdd = true;
            dataText.setText(getCurrentDate());
        } else {
            isAdd = false;
            Supply s = (Supply) serial;
            showEditUI(s);
        }
    }
    //显示物品信息更新的UI104
    private void showEditUI(Supply supply) {
        // 先将Supply携带的数据还原到supply的每一个属性中去
        supply_id = supply.getId();
        String name = supply.getName();
        int number = supply.getNumber();
        String phone = supply.getPhoneNumber();
        String data = supply.getUseDate();
        String condition = supply.getCondition();
        String attribute = supply.getAttribute();
        if (attribute.toString().equals("办公文件")) {
            button2.setChecked(true);
        } else if (attribute.toString().equals("日用工具")) {
            button1.setChecked(true);
        }
        if (condition != null && !"".equals(condition)) {
            if (box1.getText().toString().indexOf(condition) >= 0) {
                box1.setChecked(true);
            }
            if (box2.getText().toString().indexOf(condition) >= 0) {
                box2.setChecked(true);
            }
            if (box3.getText().toString().indexOf(condition) >= 0) {
                box3.setChecked(true);
            }
        }
        // 还原数据
        idText.setText(supply_id + "");
        nameText.setText(name + "");
        numberText.setText(number + "");
        phoneText.setText(phone + "");
        dataText.setText(data + "");
        setTitle("物品信息更新");
        restoreButton.setText("更新");
    }
    public void onClick(View v) {
        // 收集数据
        if (v == restoreButton) {
            if (!checkUIInput()) {// 界面输入验证
                return;
            }
            Supply supply = getSupplyFromUI();
            if (isAdd) {
                long id = dao.addSupply(supply);
                dao.closeDB();
                if (id > 0) {
                    Toast.makeText(this, "保存成功， ID=" + id,Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "保存失败，请重新输入！", Toast.LENGTH_SHORT).show();
                }
            } else if (!isAdd) {
                long id = dao.addSupply(supply);
                dao.closeDB();
                if (id > 0) {
                    Toast.makeText(this, "更新成功",Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(this, "更新失败，请重新输入！",Toast.LENGTH_SHORT).show();
                }
            }
        } else if (v == resetButton) {
            clearUIData();
        } else if (v == dataText) {
            showDialog(DATE_PICKER_ID);
        }
    }
    //       清空界面的数据176
    private void clearUIData() {
        nameText.setText("");
        numberText.setText("");
        phoneText.setText("");
        dataText.setText("");
        box1.setChecked(false);
        box2.setChecked(false);
        group.clearCheck();
    }
    //      收集界面输入的数据，并将封装成Supply对象
    private Supply getSupplyFromUI() {
        String name = nameText.getText().toString();
        int number = Integer.parseInt(numberText.getText().toString());
        String attribute = ((RadioButton) findViewById(group
                .getCheckedRadioButtonId())).getText().toString();
        String conditions = "";
        if (box1.isChecked()) { // basketball, football football
            conditions += box1.getText();
        }
        if (box2.isChecked()) {
            if (conditions.equals("")) {
                conditions += box2.getText();
            } else {
                conditions += "," + box2.getText();
            }
            if (conditions.equals("")) {
                conditions += box3.getText();
            } else {
                conditions += "," + box3.getText();
            }
        }
        String useDate = dataText.getText().toString();
        String phoneNumber = phoneText.getText().toString();
        String modifyDateTime = getCurrentDateTime();
        Supply s=new Supply(name, number, attribute, conditions, phoneNumber, useDate,
                modifyDateTime);
        if (!isAdd) {
            s.setId(Integer.parseInt(idText.getText().toString()));
            dao.deleteSupplyById(supply_id);
        }
        return s;
    }
    //      * 得到当前的日期时间
    private String getCurrentDateTime() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        return format.format(new Date());
    }
    //      * 得到当前的日期
    private String getCurrentDate() {
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
        return format.format(new Date());
    }
    //验证用户是否按要求输入了数据
    private boolean checkUIInput() { // name, number, attribute
        String name = nameText.getText().toString();
        String number = numberText.getText().toString();
        int id = group.getCheckedRadioButtonId();
        String messnumber = null;
        View invadView = null;
        if (name.trim().length() == 0) {
            messnumber = "请输入物品名称！";
            invadView = nameText;
        } else if (number.trim().length() == 0) {
            messnumber = "请输入物品编号！";
            invadView = numberText;
        } else if (id == -1) {
            messnumber = "请选择物品属性！";
        }
        if (messnumber != null) {
            Toast.makeText(this, messnumber, Toast.LENGTH_SHORT).show();
            if (invadView != null)
                invadView.requestFocus();
            return false;
        }         return true;     }
    //时间的监听与事件
    private DatePickerDialog.OnDateSetListener onDateSetListener = new DatePickerDialog.OnDateSetListener()
    {
        @Override
        public void onDateSet(DatePicker view, int year, int monthOfYear,
                              int dayOfMonth) {
            dataText.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
        }
    };
    @Override
    protected Dialog onCreateDialog(int id) {
        switch (id) {
            case DATE_PICKER_ID:
                return new DatePickerDialog(this, onDateSetListener, 2011, 8, 14);
        }
        return null;
    }
}
