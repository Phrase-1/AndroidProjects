package com.example.officemanager.Login;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.Login.Account;
import com.example.officemanager.MainActivity;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.util.List;

public class RegisterActivity<password> extends AppCompatActivity implements View.OnClickListener {

     private EditText etAcZc;
     private EditText etPwZc;
     private EditText etPwZc2;
     private Button btZcQr;

     private String username;
     private String password;
     private String password2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

       etAcZc=(EditText) findViewById(R.id.etAcZc);
       etPwZc=(EditText) findViewById(R.id.etPwZc);
       etPwZc2=(EditText) findViewById(R.id.etPwZc2);
       btZcQr=(Button) findViewById(R.id.btZcQr);

       btZcQr.setOnClickListener(this);
    }

    public int Judget(){                //判断输入用户名是否重复以及密码输入是否一致
        if (!password.equals(password2))
        {
            Toast.makeText(this, "两次输入密码不一致", Toast.LENGTH_SHORT).show();
            return 0;
        }
        if(username.length()<=0||password.length()<=0)
        {
            Toast.makeText(this, "用户名或者密码不能为空", Toast.LENGTH_SHORT).show();
            return 1;
        }


        {
            DbHelper helper = new DbHelper(this);
                try  {
                    Dao<Account, Integer> dao = helper.getDao(Account.class);
                    List<Account> account2=dao.queryBuilder().where().eq("username",username).query();//构建查询语句，不能重复注册用户名
                    if(account2.get(0).getPassword()!=null){
                            Toast.makeText(this, "该用户名已存在，请重新输入", Toast.LENGTH_SHORT).show();
                            return 2 ;
                        }
                    }
                catch (Exception e){
                    e.printStackTrace();
                    }
        }

       return 3;


    }



    @Override
    public void onClick(View v) {
        username = etAcZc.getText().toString();
        password = etPwZc.getText().toString();
        password2 = etPwZc2.getText().toString();
        switch (v.getId()) {
            case R.id.btZcQr:
                if(Judget()==3){
                    DbHelper helper = new DbHelper(this);
                try {
                    Dao<Account, Integer> dao = helper.getDao(Account.class);
                    Account account = new Account(username, password);

                    dao.create(account);
                    List<Account>accounts=dao.queryForAll();//查询所有
                    StringBuilder empstr=new StringBuilder();//创建拼接字符串用来入库（ASP）
                    for(Account f:accounts){
                        empstr.append("编号：").append(f.getId()).append("，用户名：").append(f.getUsername()).append(",密码：").append(f.getPassword());
                        //入库
                    }
                    Toast.makeText(this, "注册成功", Toast.LENGTH_SHORT).show();
                    finish();
                    Intent t = new Intent(this, MainActivity.class);
                    startActivity(t);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            break;
        }

    }
}
