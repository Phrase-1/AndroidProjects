package com.example.officemanager.Supply1;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.util.Date;

@DatabaseTable(tableName = "supply")
public class Supply1 {
    @DatabaseField(id = true)
    private int id;
    @DatabaseField(columnName = "name")
    private String name;
    @DatabaseField(columnName = "number")
    private int number;
    @DatabaseField(columnName = "arrtibute")
    private String arrtibute;
    @DatabaseField(columnName = "condition")
    private String condition;
    private boolean selected;



    public Supply1(int id, String name, int number, String arrtibute, String condition) {
        this.id = id;
        this.name = name;
        this.number = number;
        this.arrtibute = arrtibute;
        this.condition = condition;
        this.selected = false;
    }

    public Supply1() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public String getCondition() {
        return condition;
    }

    public void setCondition(String condition) {
        this.condition = condition;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }
    public String getArrtibute() {
        return arrtibute;
    }

    public void setArrtibute(String arrtibute) {
        this.arrtibute = arrtibute;
    }
}
