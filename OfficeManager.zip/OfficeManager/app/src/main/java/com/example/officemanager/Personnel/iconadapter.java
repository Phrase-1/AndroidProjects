package com.example.officemanager.Personnel;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.officemanager.R;

import java.util.ArrayList;

public class iconadapter extends BaseAdapter {
    private ArrayList<Icon> icons;
    protected Activity activity;
    public iconadapter(ArrayList<Icon> data, Activity activity)
    {
        this.icons=data;
        this.activity=activity;
    }

    public iconadapter(ArrayList<android.graphics.drawable.Icon> icon, Personnel activity) {
    }

    @Override
    public int getCount() {
        return icons.size();
    }

    @Override
    public Object getItem(int position) {
        return icons.get(position);
    }

    @Override
    public long getItemId(int position) {
        return icons.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Icon data=icons.get(position);
        RelativeLayout layout;
        ImageView imaag;
        TextView textView;

        LayoutInflater li = activity.getLayoutInflater();
        layout = (RelativeLayout) li.inflate(R.layout.item_grid, null);
        textView=(TextView)layout.findViewById(R.id.hao_2);
        imaag=(ImageView)layout.findViewById(R.id.hao_1);
        textView.setText(data.getiName());
        imaag.setImageResource(data.getiId());

        return layout;
    }
}
