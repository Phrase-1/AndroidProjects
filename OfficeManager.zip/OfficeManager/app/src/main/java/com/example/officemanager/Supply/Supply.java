package com.example.officemanager.Supply;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.io.Serializable;
//import java.util.Date;
public class Supply implements Serializable {
    private long id;
    private String name;
    private int number;
    private String attribute;
    private String condition;
    private String phoneNumber;
    private String useDate;
    private String modifyDateTime;
    public Supply() {
        super();
    }
    public Supply(long id, String name, int number, String attribute, String condition, String phoneNumber,
                  String useDate, String modifyDateTime) {
        super();
        this.id = id;
        this.name = name;
        this.number = number;
        this.attribute = attribute;
        this.condition = condition;
        this.phoneNumber = phoneNumber;
        this.useDate = useDate;
        this.modifyDateTime = modifyDateTime;
    }
    public Supply(String name, int number, String attribute, String condition, String phoneNumber,
                  String useDate, String modifyDateTime) {
        super();
        this.name = name;
        this.number = number;
        this.attribute = attribute;
        this.condition = condition;
        this.phoneNumber = phoneNumber;
        this.useDate = useDate;
        this.modifyDateTime = modifyDateTime;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
    }
    public String getAttribute() {
        return attribute;     }
    public void setAttribute(String attribute) {
        this.attribute = attribute;
    }
    public String getCondition() {
        return condition;
    }
    public void setCondition(String condition) {
        this.condition = condition;
    }
    public String getPhoneNumber() {
        return phoneNumber;
    }
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;     }
    public String getUseDate() {
        return useDate;
    }
    public void setUseDate(String useDate) {
        this.useDate = useDate;
    }
    public String getModifyDateTime() {
        return modifyDateTime;
    }
    public void setModifyDateTime(String modifyDateTime) {
        this.modifyDateTime = modifyDateTime;
    }
}
