package com.example.officemanager.Personnel;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "enployee")
public class enployee {
    @DatabaseField(id = true)
    int id;
    @DatabaseField
    String name;
    @DatabaseField
    int age;
    @DatabaseField
    int salary;
    @DatabaseField
    String tell;
    @DatabaseField
    Boolean sex;
    @DatabaseField
    String department;

    Boolean selected=false;
    Boolean on_longselected=false;

    public Boolean getOn_longselected() {
        return on_longselected;
    }

    public void setOn_longselected(Boolean on_longselected) {
        this.on_longselected = on_longselected;
    }

    public Boolean getSelected() {
        return selected;
    }

    public void setSelected(Boolean selected) {
        this.selected = selected;
    }

    public enployee() {
    }


    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public enployee(int id, String name, int age, int salary, String tell, Boolean sex, String department) {
        this.id=id;
        this.name = name;
        this.age = age;
        this.salary = salary;
        this.tell = tell;

        this.department=department;

        //hireday = (Date)LocalDate.now();
        //hireday=null;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public String getTell() {
        return tell;
    }

    public void setTell(String tell) {
        this.tell = tell;
    }

    public Boolean getSex() {
        return sex;
    }

    public void setSex(Boolean sex) {
        this.sex = sex;
    }


}
