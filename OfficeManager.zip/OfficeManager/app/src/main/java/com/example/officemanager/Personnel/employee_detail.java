package com.example.officemanager.Personnel;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.example.officemanager.R;

public class employee_detail extends AppCompatActivity {
    TextView textView1;
    TextView textView2;

    TextView textView3;
    TextView textView4;
    TextView textView5;
    TextView textView6;
    TextView textView7;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_detail_employee);
        textView1=(TextView)findViewById(R.id.ze_2);
        textView2=(TextView)findViewById(R.id.ze_4);
        textView3=(TextView)findViewById(R.id.ze_6);
        textView4=(TextView)findViewById(R.id.ze_8);
        textView5=(TextView)findViewById(R.id.ze_10);
        textView6=(TextView)findViewById(R.id.ze_22);
        textView7=(TextView)findViewById(R.id.hao_id);
        Intent a=getIntent();
        textView1.setText(a.getStringExtra("name"));
        textView2.setText(Integer.toString(a.getIntExtra("age", 1)));
        textView3.setText(Integer.toString(a.getIntExtra("salary", 1)));
        textView4.setText(a.getStringExtra("tell"));

        Boolean sex = a.getBooleanExtra("sex", false);
        if(sex==true)
            textView5.setText("男");
        else
            textView5.setText("女");
        textView6.setText(a.getStringExtra("department"));
        textView7.setText(Integer.toString(a.getIntExtra("ID",1)));
        //editText5.setText(a.getIntExtra("ID",1));





    }
}
