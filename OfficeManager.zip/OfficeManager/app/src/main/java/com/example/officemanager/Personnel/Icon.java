package com.example.officemanager.Personnel;

public class Icon {
    private int id;
    private int iId;
    private String iName;

    public Icon() {
    }

    public Icon(int id, int iId, String iName) {
        this.id=id;
        this.iId = iId;
        this.iName = iName;
    }

    public int getiId() {
        return iId;
    }
    public int getId(){
        return id;
    }
    public void setId(int id){
        this.id=id;
    }

    public String getiName() {
        return iName;
    }

    public void setiId(int iId) {
        this.iId = iId;
    }

    public void setiName(String iName) {
        this.iName = iName;
    }

}
