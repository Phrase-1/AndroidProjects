package com.example.officemanager.Personnel;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.example.officemanager.R;

import java.util.ArrayList;

public class employeeadapter extends BaseAdapter {
    private ArrayList<enployee> employees;
    protected Activity activity;
    public employeeadapter(ArrayList<enployee> data, Activity activity)
    {
        this.employees=data;
        this.activity=activity;

    }
    @Override
    public int getCount() {
        return employees.size();
    }

    @Override
    public Object getItem(int position) {
        return employees.get(position);
    }

    @Override
    public long getItemId(int position) {
        return employees.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
   enployee date=employees.get(position);
        RelativeLayout layout;

        TextView textView;
        if (convertView==null) {
            LayoutInflater li = activity.getLayoutInflater();
            layout = (RelativeLayout) li.inflate(R.layout.item_employee, null);
        }
        else{
            layout = (RelativeLayout) convertView;
        }
        textView=(TextView)layout.findViewById(R.id.han_1);
        textView.setText(date.getName());
        TextView textView1=(TextView)layout.findViewById(R.id.han_2);
        textView1.setText(date.getTell());
        ImageView Imagview=(ImageView) layout.findViewById(R.id.hao_31);
        if(date.getSex()==true)
        Imagview.setImageResource(R.drawable.nanren);
        else
            Imagview.setImageResource(R.drawable.nvrentouxiang);
        ImageView imageView=(ImageView)layout.findViewById(R.id.hao_33);
        if (date.getOn_longselected()==false)
            imageView.setImageResource(R.drawable.weixuanzhong);
        else
            imageView.setImageResource(R.drawable.xuanzhong);


        return layout;
    }
}
