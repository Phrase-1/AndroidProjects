package com.example.officemanager.Supply;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.officemanager.R;

public class ShowSupplyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_supply);
        Intent intent = getIntent();
        Supply supply = (Supply) intent.getSerializableExtra(TableContanst.SUPPLY_TABLE);
        ((TextView)findViewById(R.id.tv_show_id)).setText(supply.getId()+"");
        ((TextView)findViewById(R.id.tv_show_name)).setText(supply.getName());
        ((TextView)findViewById(R.id.tv_show_number)).setText(supply.getNumber()+"");
        ((TextView)findViewById(R.id.tv_show_attribute)).setText(supply.getAttribute());
        ((TextView)findViewById(R.id.tv_show_conditions)).setText(supply.getCondition());
        ((TextView)findViewById(R.id.tv_show_use_date)).setText(supply.getUseDate());
        ((TextView)findViewById(R.id.tv_show_phone)).setText(supply.getPhoneNumber());

    }
    public void goBack(View view) {
        finish();
    }
}
