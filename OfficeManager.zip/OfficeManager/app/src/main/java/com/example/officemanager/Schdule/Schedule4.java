package com.example.officemanager.Schdule;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;

public class Schedule4 extends AppCompatActivity implements AdapterView.OnItemClickListener,AdapterView.OnItemLongClickListener {

    private ArrayList<ScheduleNote> data;
    private ArrayList<ScheduleNote> selectedScheList;
    private ScheduleAdapter adS;
    private ListView lvS;
    private DbHelper helper;
    private Dao<ScheduleNote, Integer> sDao;
    private TextView newScheHintTv;
    private ScheduleNote selectedSche;
    private AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule4);

        initView();


//        Toolbar toolbar = findViewById(R.id.toolbar);
//        setSupportActionBar(toolbar);

        try {
            data = (ArrayList<ScheduleNote>) sDao.queryForAll();
            adS = new ScheduleAdapter(data, this);

        } catch (Exception e) {

        }
        if (data.size() == 0) {
            newScheHintTv.setVisibility(View.VISIBLE);
        } else {
            newScheHintTv.setVisibility(View.INVISIBLE);
        }
        lvS.setAdapter(adS);
        lvS.setOnItemClickListener(this);
        lvS.setOnItemLongClickListener(this);
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {
                    data = (ArrayList<ScheduleNote>) sDao.queryForAll();
                } catch (SQLException e) {
                    e.printStackTrace();
                }

                int i1;
                if (data.size() == 0) {
                    i1 = 1;
                } else {
                    int a = data.size();
                    i1 = data.get(a - 1).getId() + 1;
                }


                Intent i = new Intent(Schedule4.this, AddSchedule.class);
                i.putExtra("id", i1);
//                for(ScheduleNote s : selectedScheList){
//                    if(s.isSelected()){
//                        s.setSelected(false);
//                    }
//                }
//                selectedScheList.clear();


                startActivityForResult(i, 1);
            }
        });
    }

    protected void initView() {
        newScheHintTv = findViewById(R.id.newScheHintTv);
        helper = new DbHelper(this);
        lvS = findViewById(R.id.scheListLv);
        selectedScheList = new ArrayList<>();
        try {
            sDao = helper.getDao(ScheduleNote.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 1:
                if (resultCode == 1) {
                    try {
                        this.data = (ArrayList<ScheduleNote>) sDao.queryForAll();
                        adS = new ScheduleAdapter(this.data, this);
                        lvS.setAdapter(adS);
                        adS.notifyDataSetChanged();
                        newScheHintTv.setVisibility(View.INVISIBLE);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                break;
            case 2:
                if (resultCode == 1) {
                    try {
                        this.data = (ArrayList<ScheduleNote>) sDao.queryForAll();
                        adS = new ScheduleAdapter(this.data, this);
                        lvS.setAdapter(adS);
                        adS.notifyDataSetChanged();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
//        for(ScheduleNote s : selectedScheList){
//            if(s.isSelected()){
//                s.setSelected(false);
//            }
//        }
//        selectedScheList.clear();
        ScheduleNote sc = data.get(position);
        Intent i = new Intent(Schedule4.this, EditSchedule.class);
        i.putExtra("id", sc.getId());
        startActivityForResult(i, 2);
    }


    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

//        Toast.makeText(this,"longclick",Toast.LENGTH_SHORT).show();
        ScheduleNote sc = data.get(position);
        selectedSche = sc;
        showDeleteDialog();


        adS.notifyDataSetChanged();

//        if (!sc.isSelected()) {
//            sc.setSelected(true);
//            selectedSche = sc;
//            selectedScheList.add(selectedSche);
//            Toast.makeText(getApplicationContext(), "list=" + selectedScheList.size(), Toast.LENGTH_SHORT).show();
//            adS.notifyDataSetChanged();
//        } else {
//            sc.setSelected(false);
//            selectedSche = sc;
//            selectedScheList.remove(selectedSche);
//            //selectedSche = null;
//            Toast.makeText(getApplicationContext(), "list=" + selectedScheList.size(), Toast.LENGTH_SHORT).show();
//            adS.notifyDataSetChanged();
//
//        }
        return true;
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        menu.add(Menu.NONE, Menu.FIRST + 1, 1, "删除")
//                .setIcon(android.R.drawable.ic_menu_delete)
//                .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
//        //getMenuInflater().inflate(R.menu.schedule,menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case Menu.FIRST + 1:
//                //sDao.deleteById();
//                break;
//
//        }
//        return true;
//    }

    private void showDeleteDialog() {
        builder=new AlertDialog.Builder(this);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("是否删除此条目");
        builder.setMessage("");

        //监听下方button点击事件
        builder.setNegativeButton("删除", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                try {
                    sDao.deleteById(selectedSche.getId());
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                Toast.makeText(getApplicationContext(),"删除成功",Toast.LENGTH_SHORT).show();
                try {
                    data = (ArrayList<ScheduleNote>) sDao.queryForAll();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                if(data.size() == 0){
                    newScheHintTv.setVisibility(View.VISIBLE);
                }
                adS = new ScheduleAdapter(data, Schedule4.this);
                lvS.setAdapter(adS);
                adS.notifyDataSetChanged();
            }
        });
        builder.setPositiveButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) { }
        });

        //设置对话框是可取消的
        builder.setCancelable(true);
        AlertDialog dialog=builder.create();
        dialog.show();
    }

//    private class MultiChoiceModeListener implements AbsListView.MultiChoiceModeListener {
//
//        private ListView mListView;
//        private TextView mTitleTextView;
//        private List<Integer> mSelectedItems = new ArrayList<>();
//
//        private MultiChoiceModeListener(ListView listView) {
//            mListView = listView;
//        }
//
//        @Override
//        public void onItemCheckedStateChanged(ActionMode mode, int position, long id, boolean checked) {
//            mSelectedItems.add(mAdapter.getItem(position));
//            mTitleTextView.setText("已选择 " + mListView.getCheckedItemCount() + " 项");
//            mAdapter.notifyDataSetChanged();
//        }
//
//        @Override
//        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
//            mode.getMenuInflater().inflate(R.menu.check_task_priority, menu);
//
//            @SuppressLint("InflateParams")
//            View multiSelectActionBarView = LayoutInflater.from(MainActivity.this)
//                    .inflate(R.layout.action_mode_bar, null);
//            mode.setCustomView(multiSelectActionBarView);
//            mTitleTextView = (TextView)multiSelectActionBarView.findViewById(R.id.title);
//            mTitleTextView.setText("已选择 0 项");
//
//            mAdapter.setCheckable(true);
//            mAdapter.notifyDataSetChanged();
//            return true;
//        }
//
//        @Override
//        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
//            return false;
//        }
//
//        @Override
//        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
//            switch (item.getItemId()) {
//                case R.id.cancel:
//                    break;
//                case R.id.up:
//                    Collections.sort(mSelectedItems);
//                    for (Integer selectedItem : mSelectedItems) {
//                        mItems.remove(selectedItem);
//                    }
//                    mItems.addAll(0, mSelectedItems);
//                    break;
//                default:
//                    break;
//            }
//
//            mode.finish();
//            return true;
//        }
//
//        @Override
//        public void onDestroyActionMode(ActionMode mode) {
//            mSelectedItems.clear();
//            mAdapter.setCheckable(false);
//            mAdapter.notifyDataSetChanged();
//        }
//    }
//
//    private class CheckListViewAdapter extends ArrayAdapter<Integer> {
//
//        private boolean mCheckable;
//
//        private CheckListViewAdapter(@NonNull Context context,
//                                     @LayoutRes int resource,
//                                     @NonNull List<Integer> objects) {
//            super(context, resource, objects);
//        }
//
//        @NonNull
//        @Override
//        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
//            ViewHolder holder;
//            if (null == convertView) {
//                convertView = LayoutInflater.from(getContext())
//                        .inflate(R.layout.item_with_check_box, parent, false);
//                holder = new ViewHolder();
//                holder.textView = (TextView) convertView.findViewById(R.id.text_view);
//                holder.checkBox = (CheckBox) convertView.findViewById(R.id.selected_check_box);
//                convertView.setTag(holder);
//            } else {
//                holder = (ViewHolder) convertView.getTag();
//            }
//
//            Integer item = getItem(position);
//            if (item != null) {
//                holder.textView.setText(item.toString());
//            }
//
//            //可见性和选中状态
//            if (mCheckable) {
//                holder.checkBox.setVisibility(View.VISIBLE);
//            } else {
//                holder.checkBox.setVisibility(View.INVISIBLE);
//            }
//            holder.checkBox.setChecked(((ListView) parent).isItemChecked(position));
//
//            return convertView;
//        }
//
//        //用来设置是否CheckBox可见
//        private void setCheckable(boolean checkable) {
//            mCheckable = checkable;
//        }
//
//        private class ViewHolder {
//            private TextView textView;
//            private CheckBox checkBox;
//        }
//    }

}