package com.example.officemanager.Personnel;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;

public class add_employee extends AppCompatActivity implements View.OnClickListener {
    private EditText editText1;
    private EditText editText2;
    private EditText editText3;
    private EditText editText4;
    private EditText editText5;
    RadioGroup radioGroup;
    RadioGroup radioGroup1;
    RadioButton radioButton1;
    RadioButton radioButton2;

    RadioButton radioButton3;
    RadioButton radioButton4;
    RadioButton radioButton5;
    RadioButton radioButton6;
    RadioButton radioButton7;


    private DbHelper helper;
    private Dao<enployee,Integer> adao;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     setContentView(R.layout.layout_edit_employee);
        editText1 = (EditText) findViewById(R.id.hao_10);
        editText2 = (EditText) findViewById(R.id.hao_11);
        editText3 = (EditText) findViewById(R.id.hao_12);
        editText4 = (EditText) findViewById(R.id.hao_13);
        editText5=(EditText)findViewById(R.id.hao_22);
        radioGroup = (RadioGroup) findViewById(R.id.sexRg);
        radioGroup1=(RadioGroup)findViewById(R.id.department) ;
        radioButton1 = (RadioButton) findViewById(R.id.mal);
        radioButton2 = (RadioButton) findViewById(R.id.femal);
        radioButton3=(RadioButton)findViewById(R.id.xiaoshou);
        radioButton4=(RadioButton)findViewById(R.id.renshi);
        radioButton5=(RadioButton)findViewById(R.id.caiwu);
        radioButton6=(RadioButton)findViewById(R.id.jishu);
        radioButton7=(RadioButton)findViewById(R.id.guanli);
        Button okbt = (Button) findViewById(R.id.hao_14);
        Button cansel = (Button) findViewById(R.id.hao_15);
        okbt.setOnClickListener(this);
        cansel.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.hao_14:
                setResult(1, null);
                finish();
                break;
            case R.id.hao_15:
                Boolean sex;
                if(radioGroup.getCheckedRadioButtonId()==R.id.mal)
                    sex=true;
                else
                    sex=false;
                if(editText1.getText().toString().isEmpty()||editText2.getText().toString().isEmpty()||editText3.getText().toString().isEmpty()
                ||editText4.getText().toString().isEmpty()||editText5.getText().toString().isEmpty()
                )
                {
                    Toast.makeText(add_employee.this,"内容不能为空",Toast.LENGTH_LONG).show();
                    return;
                }

             if(0==Integer.parseInt(editText5.getText().toString()))
             {
                 Toast.makeText(add_employee.this,"当前ID不能为零",Toast.LENGTH_SHORT).show();
                 return;

             }
             if((editText2.getText().toString().length())>2)
             {
                 Toast.makeText(add_employee.this,"员工年龄不合法",Toast.LENGTH_SHORT).show();
                 return;
             }
             if(Integer.parseInt(editText2.getText().toString())>=75)
             {
                 Toast.makeText(add_employee.this,"员工年龄不能大于75岁",Toast.LENGTH_SHORT).show();
                 return;
             }
             if((editText4.getText().toString().length())!=11)
             {
                 Toast.makeText(add_employee.this,"电话号码必须为11位数字",Toast.LENGTH_SHORT).show();
                 return;
             }


                ArrayList<enployee>employee=new ArrayList<enployee>();
                helper=new DbHelper(add_employee.this);
                try {
                    adao=helper.getDao(enployee.class);
                    employee=(ArrayList<enployee>)adao.queryBuilder().where().eq("id",Integer.parseInt(editText5.getText().toString())).query();

                } catch (SQLException e) {
                    e.printStackTrace();
                }
                int count=0;
                int num=Integer.parseInt(editText5.getText().toString());
                while (num>=1){
                    num/=10;
                    count++;
                }
                if((editText5.getText().toString().length())!=count)
                {
                    Toast.makeText(add_employee.this,"无效的ID,请输入整数",Toast.LENGTH_SHORT).show();
                    return;
                }
                if (!employee.isEmpty())
                {
                    Toast.makeText(add_employee.this,"ID重复，请重新输入ID",Toast.LENGTH_LONG).show();
                    return;

                }
                count=0;
                num=Integer.parseInt(editText3.getText().toString());
                while (num>=1){
                    num/=10;
                    count++;
                }
                if((editText3.getText().toString().length())!=count)
                {
                    Toast.makeText(add_employee.this,"薪水不合法,请输入整数",Toast.LENGTH_SHORT).show();
                    return;
                }

                if(radioGroup.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(add_employee.this,"性别未选",Toast.LENGTH_LONG).show();
                    return;
                }
                if(radioGroup1.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(add_employee.this,"所属部门未选",Toast.LENGTH_LONG).show();
                    return;
                }

                Intent a=new Intent();
                if(radioGroup1.getCheckedRadioButtonId()==R.id.xiaoshou)
                    a.putExtra("department","销售部");
                if(radioGroup1.getCheckedRadioButtonId()==R.id.renshi)
                    a.putExtra("department","人事部");
                if(radioGroup1.getCheckedRadioButtonId()==R.id.jishu)
                    a.putExtra("department","技术部");
                if(radioGroup1.getCheckedRadioButtonId()==R.id.caiwu)
                    a.putExtra("department","财务部");
                if(radioGroup1.getCheckedRadioButtonId()==R.id.guanli) {
                    a.putExtra("department", "管理部");
                }
                a.putExtra("name",editText1.getText().toString());
                a.putExtra("age",Integer.parseInt(editText2.getText().toString()));
                a.putExtra("salary",Integer.parseInt(editText3.getText().toString()));
                a.putExtra("tell",editText4.getText().toString());
                a.putExtra("sex",sex);
                a.putExtra("id",Integer.parseInt(editText5.getText().toString()));
                setResult(2,a);
                finish();

                break;
        }
    }
}
