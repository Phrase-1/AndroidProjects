package com.example.officemanager.Schdule;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.officemanager.R;

import java.text.SimpleDateFormat;
import java.util.ArrayList;

public class ScheduleAdapter extends BaseAdapter {

    private ArrayList<ScheduleNote> data;
    protected Activity activity;

    public ScheduleAdapter(ArrayList<ScheduleNote> data, Activity activity) {
        this.data = data;
        this.activity = activity;
    }

    @Override
    public int getCount() {
         return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ScheduleNote sc = data.get(position);
        LinearLayout layout;
        TextView scheThemeTv;
        TextView scheAbstractTv;
        TextView scheCreateTimeTv;
        TextView scheLastEditTimeTv;
        CheckBox scheSelectedCb;
        if(convertView == null){
            LayoutInflater li = activity.getLayoutInflater();
            layout = (LinearLayout) li.inflate(R.layout.schedule_item,null);
        }else{
            layout = (LinearLayout) convertView;
        }
        scheThemeTv = layout.findViewById(R.id.scheThemeTv);
        scheAbstractTv = layout.findViewById(R.id.scheAbstractTv);
        scheCreateTimeTv = layout.findViewById(R.id.scheCreateTimeTv);
        scheLastEditTimeTv = layout.findViewById(R.id.scheLastEditTimeTv);
        scheSelectedCb = layout.findViewById(R.id.scheSelectedCb);

        scheThemeTv.setText(sc.getTheme());
        scheAbstractTv.setText(sc.getFullText());
        SimpleDateFormat formatter   =   new   SimpleDateFormat   ("yyyy年MM月dd日   HH:mm:ss");
        scheCreateTimeTv.setText(formatter.format(sc.getCreateDate()));
        scheLastEditTimeTv.setText(formatter.format(sc.getLastEditTime()));

//        if(sc.isSelected()){
//            scheSelectedCb.setVisibility(View.VISIBLE);
//            scheSelectedCb.setChecked(true);
//        }else {
//            scheSelectedCb.setVisibility(View.INVISIBLE);
//            scheSelectedCb.setChecked(false);
//        }

        return layout;
    }
}
