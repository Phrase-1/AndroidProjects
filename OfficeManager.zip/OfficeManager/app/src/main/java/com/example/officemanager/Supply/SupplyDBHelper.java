package com.example.officemanager.Supply;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class SupplyDBHelper extends SQLiteOpenHelper {
    private static final String TAG = "SupplyDBHelper";
    public static final String DB_NAME = "supply_mannumberr.db";
    public static final int VERSION = 1;    //构造方法
    public SupplyDBHelper(Context context, String name, CursorFactory factory, int version)
    {
        super(context, name, factory, version);
    }
    public SupplyDBHelper(Context context) {
        this(context, DB_NAME, null, VERSION);     }

    //创建数据库
    @Override
    public void onCreate(SQLiteDatabase db) {
        Log.v(TAG, "onCreate");
        db.execSQL("create table "
                + TableContanst.SUPPLY_TABLE                 + "(_id Integer primary key AUTOINCREMENT,"
                + "name char,number integer, attribute char, conditions char, phone_number char,use_date date, "
                + "modify_time DATETIME)");     }
    //更新数据库
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        Log.v(TAG, "onUpgrade");
    }
}
