package com.example.officemanager.Supply;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.officemanager.R;
//import com.example.officemanager.Schdule.ScheduleNote;

import java.util.ArrayList;

public class SupplyAdapter extends BaseAdapter {

    private ArrayList<Supply> data;
    protected Activity activity;

    public SupplyAdapter(ArrayList<Supply> data, Activity activity) {
        this.data = data;
        this.activity = activity;
    }

    public SupplyAdapter() {
    }
//
//    private TextView tv_stu_id;
//    private TextView tv_stu_name;
//    private TextView tv_stu_number;
//    private TextView tv_stu_attribute;
//    private TextView tv_stu_conditions;
//    private TextView tv_stu_phone;
//    private TextView tv_stu_usedate;
//    private TextView tv_stu_modifyDateTime;

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Supply s = data.get(position);
        LinearLayout layout;
        TextView tv_stu_id;
        TextView tv_stu_name;
        TextView tv_stu_number;
        TextView tv_stu_attribute;
        TextView tv_stu_conditions;
        TextView tv_stu_phone;
        TextView tv_stu_usedate;
        TextView tv_stu_modifyDateTime;

        if(convertView == null){
            LayoutInflater li = activity.getLayoutInflater();
            layout = (LinearLayout) li.inflate(R.layout.supply_list_item,null);
        }else{
            layout = (LinearLayout) convertView;
        }

        tv_stu_id = layout.findViewById(R.id.tv_stu_id);
        tv_stu_name = layout.findViewById(R.id.tv_stu_name);
//        tv_stu_number = layout.findViewById(R.id.tv_stu_number);
//        tv_stu_attribute = layout.findViewById(R.id.tv_stu_attribute);
//        tv_stu_conditions = layout.findViewById(R.id.tv_stu_conditions);
//        tv_stu_phone = layout.findViewById(R.id.tv_stu_phone);
//        tv_stu_usedate = layout.findViewById(R.id.tv_stu_usedate);
//        tv_stu_modifyDateTime = layout.findViewById(R.id.tv_stu_modifyDateTime);

        tv_stu_id.setText(String.valueOf(s.getId()));
        tv_stu_name.setText(s.getName());
//        tv_stu_number.setText(s.getNumber());
//        tv_stu_attribute.setText(s.getAttribute());
//        tv_stu_conditions.setText(s.getCondition());
//        tv_stu_phone.setText(s.getPhoneNumber());
//        tv_stu_usedate.setText(s.getUseDate());
//        tv_stu_modifyDateTime.setText(s.getModifyDateTime());


        return layout;
    }
}
