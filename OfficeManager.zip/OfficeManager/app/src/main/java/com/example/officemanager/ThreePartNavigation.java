package com.example.officemanager;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Toast;

import com.example.officemanager.Personnel.Personnel;
import com.example.officemanager.Schdule.AddSchedule;
import com.example.officemanager.Schdule.Schedule4;
import com.example.officemanager.Schdule.ScheduleNote;
import com.example.officemanager.Supply.Supplies_list;
import com.j256.ormlite.dao.Dao;

public class ThreePartNavigation extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener,View.OnLongClickListener, AdapterView.OnItemLongClickListener {
    private Button scheduleBt;
    private Button personnelBt;
    private Button toolBt;
    private Button aboutApp;
    private AlertDialog.Builder builder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_three_part_navigation);
        initView();
        toolBt.setOnClickListener(this);
        personnelBt.setOnClickListener(this);
        scheduleBt.setOnClickListener(this);
        aboutApp.setOnClickListener(this);
    }

    private void initView(){
        scheduleBt = findViewById(R.id.scheduleBt);
        personnelBt = findViewById(R.id.personnelBt);
        toolBt = findViewById(R.id.toolBt);
        aboutApp = findViewById(R.id.aboutApp);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.scheduleBt:
                Intent scheI = new Intent(ThreePartNavigation.this, Schedule4.class);
                startActivity(scheI);
                break;
            case R.id.toolBt:
                Intent toolI = new Intent(ThreePartNavigation.this, Supplies_list.class);
                startActivity(toolI);
                break;
            case R.id.personnelBt:
                Intent personI = new Intent(ThreePartNavigation.this, Personnel.class);
                startActivity(personI);
                break;
            case R.id.aboutApp:
                showSimpleDialog();
                break;
        }

    }



    @Override
    public boolean onLongClick(View v) {
        return false;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }

    private void showSimpleDialog() {
        builder=new AlertDialog.Builder(this);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("Presented by");
        builder.setMessage("韩泽浩 闫博远 王文炜");


        //设置对话框是可取消的
        builder.setCancelable(true);
        AlertDialog dialog=builder.create();
        dialog.show();
    }
}
