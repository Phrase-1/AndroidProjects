package com.example.officemanager;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import com.example.officemanager.Login.Account;
import com.example.officemanager.Personnel.enployee;
import com.example.officemanager.Schdule.ScheduleNote;
import com.example.officemanager.Supply.Supply;
import com.example.officemanager.Supply1.Supply1;
import com.j256.ormlite.android.apptools.OrmLiteSqliteOpenHelper;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.table.TableUtils;

import java.sql.SQLException;

public class DbHelper extends OrmLiteSqliteOpenHelper {
    public DbHelper(Context context) {

        super(context, "s.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase, ConnectionSource connectionSource) {
        try {
            TableUtils.createTable(connectionSource, ScheduleNote.class);
            TableUtils.createTable(connectionSource, Account.class);
            TableUtils.createTable(connectionSource, Supply1.class);
            TableUtils.createTable(connectionSource, enployee.class);
            int a = 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, ConnectionSource connectionSource, int i, int i1) {
        try {
            TableUtils.dropTable(connectionSource, ScheduleNote.class, true);
            onCreate(sqLiteDatabase, connectionSource);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
