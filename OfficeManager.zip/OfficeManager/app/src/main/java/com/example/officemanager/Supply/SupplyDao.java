package com.example.officemanager.Supply;

import android.content.ContentValues;
import android.database.Cursor;
import android.view.View;
import android.widget.TextView;

import com.example.officemanager.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class SupplyDao {
    private SupplyDBHelper dbHelper;
    private Cursor cursor;
    public SupplyDao(SupplyDBHelper dbHelper) {
        this.dbHelper = dbHelper;
    }
    // 添加一个Supply对象数据到数据库表
    public long addSupply(Supply s) {
        ContentValues values = new ContentValues();
        values.put(TableContanst.SupplyColumns.NAME, s.getName());
        values.put(TableContanst.SupplyColumns.NUMBER, s.getNumber());
        values.put(TableContanst.SupplyColumns.ATTRIBUTE, s.getAttribute());
        values.put(TableContanst.SupplyColumns.CONDITION, s.getCondition());
        values.put(TableContanst.SupplyColumns.PHONE_NUMBER, s.getPhoneNumber());
        values.put(TableContanst.SupplyColumns.TRAIN_DATE, s.getUseDate());
        values.put(TableContanst.SupplyColumns.MODIFY_TIME, s.getModifyDateTime());
        return dbHelper.getWritableDatabase().insert(TableContanst.SUPPLY_TABLE, null, values);
    }

    // 删除一个id所对应的数据库表supply的记录
    public int deleteSupplyById(long id) {
        return dbHelper.getWritableDatabase().delete(TableContanst.SUPPLY_TABLE,
                TableContanst.SupplyColumns.ID + "=?", new String[] { id + "" });
    }

    // 更新一个id所对应数据库表supply的记录
    public int updateSupply(Supply s) {
        ContentValues values = new ContentValues();
        values.put(TableContanst.SupplyColumns.NAME, s.getName());
        values.put(TableContanst.SupplyColumns.NUMBER, s.getNumber());
        values.put(TableContanst.SupplyColumns.ATTRIBUTE, s.getAttribute());
        values.put(TableContanst.SupplyColumns.CONDITION, s.getCondition());
        values.put(TableContanst.SupplyColumns.PHONE_NUMBER, s.getPhoneNumber());
        values.put(TableContanst.SupplyColumns.TRAIN_DATE, s.getUseDate());
        values.put(TableContanst.SupplyColumns.MODIFY_TIME, s.getModifyDateTime());
        return dbHelper.getWritableDatabase().update(TableContanst.SUPPLY_TABLE, values,
                TableContanst.SupplyColumns.ID + "=?", new String[] { s.getId() + "" });
    }
    // 查询所有的记录
    public List<Map<String,Object>> getAllSupplys() {
        //modify_time desc
        List<Map<String, Object>> data = new ArrayList<Map<String,Object>>();
        Cursor cursor = dbHelper.getWritableDatabase().query(TableContanst.SUPPLY_TABLE, null, null, null,
                null, null, TableContanst.SupplyColumns.MODIFY_TIME+" desc");
        while(cursor.moveToNext()) {
            Map<String, Object> map = new HashMap<String, Object>(8);
            long id = cursor.getInt(cursor.getColumnIndex(TableContanst.SupplyColumns.ID));
            map.put(TableContanst.SupplyColumns.ID, id);
            String name = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.NAME));
            map.put(TableContanst.SupplyColumns.NAME, name);
            int number = cursor.getInt(cursor.getColumnIndex(TableContanst.SupplyColumns.NUMBER));
            map.put(TableContanst.SupplyColumns.NUMBER, number);
            String attribute = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.ATTRIBUTE));
            map.put(TableContanst.SupplyColumns.ATTRIBUTE, attribute);
            String conditions = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.CONDITION));
            map.put(TableContanst.SupplyColumns.CONDITION, conditions);
            String phone_number = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.PHONE_NUMBER));
            map.put(TableContanst.SupplyColumns.PHONE_NUMBER, phone_number);
            String use_date = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.TRAIN_DATE));
            map.put(TableContanst.SupplyColumns.TRAIN_DATE, use_date);
            String modify_time = cursor.getString(cursor.getColumnIndex(TableContanst.SupplyColumns.MODIFY_TIME));
            map.put(TableContanst.SupplyColumns.MODIFY_TIME, modify_time);
            data.add(map);
        }
        return data;
    }
    //模糊查询一条记录
    public Cursor findSupply(String name){
        Cursor cursor = dbHelper.getWritableDatabase().query(TableContanst.SUPPLY_TABLE,  null, "name condition ?",
                new String[] { "%" + name + "%" }, null, null, null,null);
        return cursor;      }
    //按物品名称进行排序
    public Cursor sortByName(){
        Cursor cursor = dbHelper.getWritableDatabase().query(TableContanst.SUPPLY_TABLE,  null,null,
                null, null, null,TableContanst.SupplyColumns.NAME);
        return cursor;     }
    //按日期进行排序
    public Cursor sortByUseDate(){
        Cursor cursor = dbHelper.getWritableDatabase().query(TableContanst.SUPPLY_TABLE,  null,null,
                null, null, null,TableContanst.SupplyColumns.TRAIN_DATE);
        return cursor;
    }
    //按id进行排序
    public Cursor sortByID(){
        Cursor cursor = dbHelper.getWritableDatabase().query(TableContanst.SUPPLY_TABLE,  null,null,
                null, null, null,TableContanst.SupplyColumns.ID);
        return cursor;    }
    public void closeDB() {
        dbHelper.close();     }   //自定义的方法通过View和Id得到一个supply对象
    public Supply getSupplyFromView(View view, long id) {
        TextView nameView = (TextView) view.findViewById(R.id.tv_stu_name);
        TextView numberView = (TextView) view.findViewById(R.id.tv_stu_number);
        TextView attributeView = (TextView) view.findViewById(R.id.tv_stu_attribute);
        TextView conditionView = (TextView) view.findViewById(R.id.tv_stu_conditions);
        TextView phoneView = (TextView) view.findViewById(R.id.tv_stu_phone);
        TextView dataView = (TextView) view.findViewById(R.id.tv_stu_usedate);
        String name = nameView.getText().toString();
        int number = Integer.parseInt(numberView.getText().toString());
        String attribute = attributeView.getText().toString();
        String condition = conditionView.getText().toString();
        String phone = phoneView.getText().toString();
        String data = dataView.getText().toString();
        Supply supply = new Supply(id, name, number, attribute, condition, phone, data,null);
        return
                supply;
    }
}

