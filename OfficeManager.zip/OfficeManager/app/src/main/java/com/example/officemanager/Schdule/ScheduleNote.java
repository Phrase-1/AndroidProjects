package com.example.officemanager.Schdule;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

import java.util.Date;

@DatabaseTable(tableName = "schedule")
public class ScheduleNote {
    @DatabaseField(id = true)
    private int id;
    @DatabaseField(canBeNull = false,columnName = "creatDate")
    private Date createDate;
    @DatabaseField(columnName = "theme")
    private String theme;
    @DatabaseField(columnName = "fullText")
    private String fullText;
    @DatabaseField(columnName = "lastEditTime")
    private Date lastEditTime;

    private boolean selected;

    public ScheduleNote() {
    }

    public Date getLastEditTime() {
        return lastEditTime;
    }

    public boolean isSelected() {
        return selected;
    }

    public void setSelected(boolean selected) {
        this.selected = selected;
    }

    public void setLastEditTime(Date lastEditTime) {
        this.lastEditTime = lastEditTime;
    }

    public ScheduleNote(int id, String theme, String fullText, Date createDate) {
        this.id = id;
        this.createDate = createDate;
        this.theme = theme;
        this.fullText = fullText;
        this.lastEditTime = createDate;
        selected = false;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreateDate() {
        return createDate;
    }

    public void setCreateDate(Date createDate) {
        this.createDate = createDate;
    }

    public String getTheme() {
        return theme;
    }

    public void setTheme(String theme) {
        this.theme = theme;
    }

    public String getFullText() {
        return fullText;
    }

    public void setFullText(String fullText) {
        this.fullText = fullText;
    }
}
