package com.example.officemanager.Schdule;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EditSchedule extends AppCompatActivity {

    private TextView systemTimeTv;
    private EditText editScheThemeEt;
    private EditText editScheAllEt;
    private AlertDialog.Builder builder;
    private Intent i;
    private SimpleDateFormat formatter;
    private Date curDate;
    private Date lastEditDate;
    private Dao<ScheduleNote,Integer> sDao;
    private DbHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_schedule);

        initView();
        int id = i.getIntExtra("id",1);

        try {
            editScheThemeEt.setText(sDao.queryForId(i.getIntExtra("id",1)).getTheme());
            editScheAllEt.setText(sDao.queryForId(i.getIntExtra("id",1)).getFullText());
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        Toast.makeText(this,"按下返回键",Toast.LENGTH_SHORT).show();
        if(!editScheThemeEt.getText().toString().equals("")||!editScheAllEt.getText().toString().equals("")){
            showSimpleDialog();
        }
        else finish();

    }

    protected void initView(){
        systemTimeTv = findViewById(R.id.systemTimeTv);
        editScheThemeEt = findViewById(R.id.editScheThemeEt);
        editScheAllEt = findViewById(R.id.editScheAllEt);
        //builder = new AlertDialog.builder(this);
        i = getIntent();
        formatter   =   new   SimpleDateFormat   ("yyyy年MM月dd日   HH:mm:ss");
        curDate =  new Date(System.currentTimeMillis());
        helper = new DbHelper(this);
        try {
            sDao = helper.getDao(ScheduleNote.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void showSimpleDialog() {
        builder=new AlertDialog.Builder(this);
        builder.setIcon(R.mipmap.ic_launcher);
        builder.setTitle("确定要离开此页吗");
        builder.setMessage("所有更改将会丢失");

        //监听下方button点击事件
        builder.setNegativeButton("离开", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setPositiveButton("保存", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if(!editScheThemeEt.getText().toString().equals("") || !editScheAllEt.getText().toString().equals("")){
                    try {
                        lastEditDate = sDao.queryForId(i.getIntExtra("id",1)).getCreateDate();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    ScheduleNote sc = new ScheduleNote(i.getIntExtra("id",1),editScheThemeEt.getText().toString(),editScheAllEt.getText().toString(),lastEditDate);
                    sc.setLastEditTime(curDate);
                    try{
                        Dao<ScheduleNote,Integer> sDao = helper.getDao(ScheduleNote.class);
                        sDao.update(sc);
                    }catch (Exception e){

                    }
                }
                Toast.makeText(getApplicationContext(),"保存成功",Toast.LENGTH_SHORT).show();
                setResult(1);
                finish();
            }
        });

        //设置对话框是可取消的
        builder.setCancelable(true);
        AlertDialog dialog=builder.create();
        dialog.show();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(Menu.NONE,Menu.FIRST  + 1,1,"保存")
                .setIcon(android.R.drawable.ic_menu_save)
                .setShowAsAction(MenuItem.SHOW_AS_ACTION_ALWAYS);
        //getMenuInflater().inflate(R.menu.schedule,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch(item.getItemId()){
            case Menu.FIRST + 1:

                Intent data = new Intent();
                if(!editScheThemeEt.getText().toString().equals("") || !editScheAllEt.getText().toString().equals("")){
                    try {
                        lastEditDate = sDao.queryForId(i.getIntExtra("id",1)).getCreateDate();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    ScheduleNote sc = new ScheduleNote(i.getIntExtra("id",1),editScheThemeEt.getText().toString(),editScheAllEt.getText().toString(),lastEditDate);
                    sc.setLastEditTime(curDate);
                    try{
                        Dao<ScheduleNote,Integer> sDao = helper.getDao(ScheduleNote.class);
                        sDao.update(sc);
                    }catch (Exception e){

                    }
                }


                Toast.makeText(this,"保存成功",Toast.LENGTH_SHORT).show();
                setResult(1);
                finish();
                break;
        }
        return true;
    }
}
