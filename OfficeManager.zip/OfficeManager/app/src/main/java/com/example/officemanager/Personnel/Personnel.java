package com.example.officemanager.Personnel;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ListView;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;

public class Personnel extends AppCompatActivity {
    public iconadapter ad;
    private ArrayList<Icon> Icon=null;
    private Intent a;
    private DbHelper helper;
    private Dao<enployee,Integer> adao;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_personnel);
        GridView gridView=(GridView)findViewById(R.id.hao_3) ;
        Icon=new ArrayList<>();
        Icon.add(new Icon(1,R.drawable.dongshichang,"集团董事"));
        Icon.add(new Icon(2,R.drawable.xiaoshoubu,"销售部"));
        Icon.add(new Icon(3,R.drawable.renshibu,"人事部"));
        Icon.add(new Icon(4,R.drawable.caiwubu,"财务部"));
        Icon.add(new Icon(5,R.drawable.jishubu,"技术部"));
        Icon.add(new Icon(6,R.drawable.guanlibumen,"管理部"));

        Icon.add(new Icon(7,R.drawable.add,"添加人员"));

        ad=new iconadapter(Icon,this);
        gridView.setAdapter(ad);
        //-------------------------------------------------------------------------------------------------
        helper=new DbHelper(Personnel.this);
        try {
            adao=helper.getDao(enployee.class);


        } catch (SQLException e) {
            e.printStackTrace();
        }

        gridView.setOnItemClickListener(new GridView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                switch (Icon.get(position).getId())
                {
                    case 1:
                        //Toast.makeText(getApplicationContext(),"id = 1",Toast.LENGTH_SHORT).show();


                        a = new Intent(Personnel.this,dongshi.class);
                        // a.setClass(Personnel.this, dongshi.class);
                        startActivity(a);
                        break;
                    case 2:
                        a = new Intent(Personnel.this,people2.class);
                        // a.setClass(Personnel.this, people2.class);
                        a.putExtra("id","销售部");

                        startActivity(a);
                        break;
                    case 3:
                        a = new Intent(Personnel.this,people2.class);
                        // a.setClass(Personnel.this, people2.class);
                        a.putExtra("id","人事部");

                        startActivity(a);
                        break;
                    case 4:
                        a = new Intent(Personnel.this,people2.class);
                        //a.setClass(Personnel.this, people2.class);
                        a.putExtra("id","财务部");

                        startActivity(a);
                        break;
                    case 5:
                        a = new Intent(Personnel.this,people2.class);
                        //a.setClass(Personnel.this, people2.class);
                        a.putExtra("id","技术部");

                        startActivity(a);
                        break;
                    case 6:
                        a = new Intent(Personnel.this,people2.class);
                        //a.setClass(Personnel.this, people2.class);
                        a.putExtra("id","管理部");

                        startActivity(a);
                        break;
                    case 7:
                        a=new Intent(Personnel.this,add_employee.class);
                        a.putExtra("id","添加人员");
                        startActivityForResult(a,1);
                }
            }});
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case 1:
                if(resultCode==2)
                {
                    enployee newenployee=new enployee();
                    newenployee.setId(data.getIntExtra("id",1));
                    newenployee.setName(data.getStringExtra("name"));
                    newenployee.setAge(data.getIntExtra("age",1));
                    newenployee.setSalary(data.getIntExtra("salary",1));
                    newenployee.setTell(data.getStringExtra("tell"));
                    newenployee.setSex(data.getBooleanExtra("sex",false));
                    newenployee.setDepartment(data.getStringExtra("department"));
                    helper=new DbHelper(Personnel.this);
                    ListView listView=(ListView)findViewById(R.id.hao_6);
                    try {
                        adao=helper.getDao(enployee.class);
                        adao.create(newenployee);
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }
                break;
        }
    }
}
