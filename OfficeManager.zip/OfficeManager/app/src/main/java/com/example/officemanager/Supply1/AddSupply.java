//package com.example.officemanager.Supply1;
//
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.EditText;
//import android.widget.RadioButton;
//import android.widget.RadioGroup;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.example.officemanager.R;
//import com.example.officemanager.Supply.Supply;
//import com.example.officemanager.Supply.SupplyDBHelper;
//import com.example.officemanager.Supply.SupplyDao;
//
//public class AddSupply extends AppCompatActivity implements View.OnClickListener {
//
//    private TextView idText;
//    private EditText nameText;
//    private EditText numberText;
//    private EditText phoneText;
//    private EditText dataText;
//    private RadioGroup group;
//    private RadioButton button1;
//    private RadioButton button2;
//    private CheckBox box1;
//    private CheckBox box2;
//    private CheckBox box3;
//    private Button restoreButton;
//    private String attribute;
//    private Button resetButton;
//    private Long supply_id;
//    private SupplyDao dao;
//    private boolean isAdd = true;
//
////    private EditText et_name;
////    private EditText et_number;
////    private RadioGroup rg_attribute;
////    private RadioButton rb_attribute_male;
////    private RadioButton rb_attribute_female;
////    private CheckBox box1;
////    private CheckBox box2;
////    private CheckBox box3;
////    private EditText et_phone;
////    private Button btn_save;
////    private Button btn_clear;
//
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_add_supply2);
//
//        idText = (TextView) findViewById(R.id.tv_stu_id);
//        nameText = (EditText) findViewById(R.id.et_name);
//        numberText = (EditText) findViewById(R.id.et_number);
//        button1 = (RadioButton) findViewById(R.id.rb_attribute_female);
//        button2 = (RadioButton) findViewById(R.id.rb_attribute_male);
//        phoneText = (EditText) findViewById(R.id.et_phone);
//        dataText = (EditText) findViewById(R.id.et_usedate);
//        group = (RadioGroup) findViewById(R.id.rg_attribute);
//        box1 = (CheckBox) findViewById(R.id.box1);
//        box2 = (CheckBox) findViewById(R.id.box2);
//        box3 = (CheckBox) findViewById(R.id.box3);
//        restoreButton = (Button) findViewById(R.id.btn_save);
//        resetButton = (Button) findViewById(R.id.btn_clear);
//        restoreButton.setOnClickListener(this);
//        resetButton.setOnClickListener(this);
//        dataText.setOnClickListener(this);
//    }
//
//    @Override
//    public void onClick(View v) {
//        // 收集数据
//        if (v == restoreButton) {
//            //if (!checkUIInput()) {// 界面输入验证
//                return;
//            }
//            Supply supply = getSupplyFromUI();
//            if (isAdd) {
//                long id = dao.addSupply(supply);
//                dao.closeDB();
//                if (id > 0) {
//                    Toast.makeText(this, "保存成功， ID=" + id,Toast.LENGTH_SHORT).show();
//                    finish();
//                } else {
//                    Toast.makeText(this, "保存失败，请重新输入！", Toast.LENGTH_SHORT).show();
//                }
//            } else if (!isAdd) {
//                long id = dao.addSupply(supply);
//                dao.closeDB();
//                if (id > 0) {
//                    Toast.makeText(this, "更新成功",Toast.LENGTH_SHORT).show();
//                    finish();
//                } else {
//                    Toast.makeText(this, "更新失败，请重新输入！",Toast.LENGTH_SHORT).show();
//                }
//            }
//        } else if (v == resetButton) {
//            clearUIData();
//        } else if (v == dataText) {
//            //showDialog(DATE_PICKER_ID);
//        }
//    }
//
//    private void clearUIData() {
//        nameText.setText("");
//        numberText.setText("");
//        phoneText.setText("");
//        dataText.setText("");
//        box1.setChecked(false);
//        box2.setChecked(false);
//        group.clearCheck();
//    }
//
////    public void initView(){
////        et_name = findViewById(R.id.et_name);
////        et_number = findViewById(R.id.et_number);
////        rg_attribute = findViewById(R.id.rg_attribute);
////        rb_attribute_male = findViewById(R.id.rb_attribute_male);
////        rb_attribute_female = findViewById(R.id.rb_attribute_female);
////        box1 = findViewById(R.id.box1);
////        box2 = findViewById(R.id.box2);
////        box3 = findViewById(R.id.box3);
////        et_phone = findViewById(R.id.et_phone);
////        btn_save = findViewById(R.id.btn_save);
////        btn_save = findViewById(R.id.btn_clear);
////    }
//}
