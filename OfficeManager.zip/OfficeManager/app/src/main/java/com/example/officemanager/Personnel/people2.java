package com.example.officemanager.Personnel;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import com.example.officemanager.DbHelper;
import com.example.officemanager.R;
import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;

public class people2 extends AppCompatActivity {
    private ArrayList<enployee>employee;
    protected employeeadapter employeeadapter;
    private Intent a;
    private Intent b;
    private DbHelper helper;
    private Dao<enployee,Integer> adao;
    private enployee enployee_selected=null;
    private enployee on_longselectsd=null;



    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode){
        case 1:
            if(resultCode==1) {
                on_longselectsd.setName(data.getStringExtra("name"));
                on_longselectsd.setAge(data.getIntExtra("age", 1));
                on_longselectsd.setSalary(data.getIntExtra("salary", 1));
                on_longselectsd.setTell(data.getStringExtra("tell"));
                on_longselectsd.setSex(data.getBooleanExtra("sex", false));
                on_longselectsd.setDepartment(data.getStringExtra("department"));
                //on_longselectsd.setId(data.getIntExtra("id",1000));
                on_longselectsd.setId(data.getIntExtra("id",1000));

                helper = new DbHelper(people2.this);
                try {
                    adao = helper.getDao(enployee.class);
                    adao.update(on_longselectsd);
                    Intent bd=getIntent();
                    employee=(ArrayList<enployee>)adao.queryBuilder().where().eq("department",bd.getStringExtra("id")).query();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                on_longselectsd.setOn_longselected(false);
                on_longselectsd=null;
                employeeadapter=new employeeadapter(employee,this);
                if(employee.isEmpty())
                { Toast.makeText(people2.this, "当前暂无员工信息，请回到主界面添加", Toast.LENGTH_SHORT).show();}
                ListView listView=(ListView)findViewById(R.id.hao_6);
                listView.setAdapter(employeeadapter);
                employeeadapter.notifyDataSetChanged();
            }

            break;
            /*
            case 2:


                if(resultCode==2)
                {
                    enployee newenployee=new enployee();
                    newenployee.setId(data.getIntExtra("id",1));
                    newenployee.setName(data.getStringExtra("name"));
                    newenployee.setAge(data.getIntExtra("age",1));
                    newenployee.setSalary(data.getIntExtra("salary",1));
                    newenployee.setTell(data.getStringExtra("tell"));
                    newenployee.setSex(data.getBooleanExtra("sex",false));
                    newenployee.setDepartment(data.getStringExtra("department"));
                    helper=new DbHelper(people2.this);
                    ListView listView=(ListView)findViewById(R.id.hao_6);
                    try {
                        adao=helper.getDao(enployee.class);
                        adao.create(newenployee);
                        employee=(ArrayList<enployee>)adao.queryForAll();
                        employeeadapter=new employeeadapter(employee,this);
                        listView.setAdapter(employeeadapter);
                        employeeadapter.notifyDataSetChanged();
                        } catch (SQLException e) {
                        e.printStackTrace();
                    }
                    employeeadapter.notifyDataSetChanged();

                }
                break;
                */


        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.people2);
    employee=new ArrayList<>();
         ListView listView=(ListView)findViewById(R.id.hao_6);
        final Intent bd=getIntent();
         final String departmet=bd.getStringExtra("id");
        helper=new DbHelper(people2.this);
        try {
            adao=helper.getDao(enployee.class);
            employee=(ArrayList<enployee>)adao.queryBuilder().where().eq("department",bd.getStringExtra("id")).query();

        } catch (SQLException e) {
            e.printStackTrace();
        }
        if(employee.isEmpty())
        { Toast.makeText(people2.this, "当前暂无员工信息，请回到主界面添加", Toast.LENGTH_SHORT).show();}
        employeeadapter=new employeeadapter(employee,this);
        listView.setAdapter(employeeadapter);
    //--------------------------------------------------------------------------------------------
    listView.setOnItemClickListener(new ListView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
    if (enployee_selected==null)
    {
        enployee_selected=employee.get(position);
        enployee_selected.setSelected(true);
    }
    else
    {
    enployee_selected.setSelected(false);
    enployee_selected=employee.get(position);
    enployee_selected.setSelected(true);
    }
            a=new Intent(people2.this,employee_detail.class);
            a.putExtra("ID",enployee_selected.getId());
            a.putExtra("name",enployee_selected.getName());
            a.putExtra("age",enployee_selected.getAge());
            a.putExtra("salary",enployee_selected.getSalary());
            a.putExtra("department",enployee_selected.getDepartment());
            a.putExtra("tell",enployee_selected.getTell());
            a.putExtra("sex",enployee_selected.getSex());
            startActivityForResult(a,3);
        }
    });



    listView.setOnItemLongClickListener(new ListView.OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            if (on_longselectsd==null)
            {
                on_longselectsd=employee.get(position);
                on_longselectsd.setOn_longselected(true);
                employeeadapter.notifyDataSetChanged();
                return true;
            }
            else
            {
                if(employee.get(position).getOn_longselected()==true){
                    on_longselectsd.setOn_longselected(false);
                    employeeadapter.notifyDataSetChanged();
                    return true;
                }
                on_longselectsd.setOn_longselected(false);
                on_longselectsd=employee.get(position);
                on_longselectsd.setOn_longselected(true);
                employeeadapter.notifyDataSetChanged();
                return true;
            }



        }

    });

//----------------------------------------------------------------------------------------------------------

        Button buttonedit=(Button)findViewById(R.id.hao_9);
        buttonedit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(on_longselectsd!= null){
                   if (on_longselectsd.getOn_longselected() == false) {
                       Toast.makeText(people2.this, "请长按选择员工", Toast.LENGTH_SHORT).show();
                       return;
                   } else
                       a=new Intent(people2.this,edit_enployee.class);
                   a.putExtra("ID",on_longselectsd.getId());
                   a.putExtra("name",on_longselectsd.getName());
                   a.putExtra("age",on_longselectsd.getAge());
                   a.putExtra("salary",on_longselectsd.getSalary());
                   a.putExtra("department",on_longselectsd.getDepartment());
                   a.putExtra("tell",on_longselectsd.getTell());
                   a.putExtra("sex",on_longselectsd.getSex());
                   startActivityForResult(a,1);
               }
               else
                   Toast.makeText(people2.this, "请长按选择员工", Toast.LENGTH_SHORT).show();
                return;

            }
        });


/*
        Button buttonadd=(Button)findViewById(R.id.hao_7);
        buttonadd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent a=new Intent(people2.this,add_employee.class);
                a.putExtra("department",departmet);
                startActivityForResult(a,2);
            }
        });
        */

////------------------------------------------------------------------------------------------------
        Button buttondelete=(Button)findViewById(R.id.hao_8);
        buttondelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (on_longselectsd!= null) {

                    if (on_longselectsd.getOn_longselected() == false) {
                        Toast.makeText(people2.this, "请长按选择员工", Toast.LENGTH_SHORT).show();
                        return;
                    } else

                        try {

                            adao.delete(on_longselectsd);

                            employee = (ArrayList<enployee>) adao.queryBuilder().where().eq("department",bd.getStringExtra("id")).query();


                        } catch (SQLException e) {
                            e.printStackTrace();
                        }
                        on_longselectsd=null;
                    ListView listView = (ListView) findViewById(R.id.hao_6);
                    employeeadapter = new employeeadapter(employee, people2.this);
                    listView.setAdapter(employeeadapter);
                    employeeadapter.notifyDataSetChanged();
                }
                else
                    Toast.makeText(people2.this, "请长按选择员工", Toast.LENGTH_SHORT).show();
                    return;
            }





        });
            }//oncreate的
}


