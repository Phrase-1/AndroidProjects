package com.example.officemanager.Supply;

public final class TableContanst {
    public static final String SUPPLY_TABLE = "supply";
    public static final class SupplyColumns {
        public static final String ID = "_id";
        public static final String NAME = "name";
        public static final String NUMBER = "number";
        public static final String ATTRIBUTE = "attribute";
        public static final String CONDITION = "conditions";
        public static final String PHONE_NUMBER = "phone_number";
        public static final String TRAIN_DATE = "use_date";
        public static final String MODIFY_TIME = "modify_time";
    }
}