package com.example.myapplication;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class StudentAdapter extends BaseAdapter {

    private ArrayList<Student> data;
    protected Activity activity;

    public StudentAdapter(ArrayList<Student> data, Activity activity){
        this.data = data;
        this.activity = activity;
    }

    @Override
    public int getCount() {
        return data.size();
    }

    @Override
    public Object getItem(int position) {
        return data.get(position);
    }

    @Override
    public long getItemId(int position) {
        return data.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Student s = data.get(position);
        RelativeLayout layout;
        TextView noTv;
        TextView nameTv;
        TextView sexTv;
        ImageView seIv;
        if(convertView == null) {
            LayoutInflater li = activity.getLayoutInflater();
            layout = (RelativeLayout) li.inflate(R.layout.student_item, null);
        }else{
            layout = (RelativeLayout) convertView;
        }
        noTv = layout.findViewById(R.id.noTv);
        nameTv = layout.findViewById(R.id.nameTv);
        sexTv = layout.findViewById(R.id.sexTv);
        seIv = layout.findViewById(R.id.selectedIv);
        noTv.setText(s.getNo());
        nameTv.setText(s.getName());
        if(s.isSex())
            sexTv.setText("女");
        else sexTv.setText("男");
        if(s.isSelected())
            seIv.setImageResource(R.mipmap.select);
        else seIv.setImageResource(R.mipmap.unselect);

        return layout;
    }
}
