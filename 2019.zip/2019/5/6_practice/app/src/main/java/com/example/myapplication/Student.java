package com.example.myapplication;

import com.j256.ormlite.field.DatabaseField;
import com.j256.ormlite.table.DatabaseTable;

@DatabaseTable(tableName = "students")
public class Student {
    @DatabaseField(id = true)
    private int id;
    @DatabaseField(canBeNull = false,columnName = "no")
    private String no;
    @DatabaseField(columnName = "name")
    private String name;
    @DatabaseField(columnName = "sex")
    private boolean sex;
    private boolean isSelected;

    public Student() {
    }

    public Student(int id, String no, String name, boolean sex){
        this.id = id;
        this.no = no;
        this.name = name;
        this.sex = sex;
        isSelected = false;
    }
    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isSex() {
        return sex;
    }

    public void setSex(boolean sex) {
        this.sex = sex;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean isselected) {
        this.isSelected = isselected;
    }
}
