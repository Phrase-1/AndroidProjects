package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.sax.TextElementListener;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class EditActivity extends AppCompatActivity implements View.OnClickListener {

    private EditText noEt;
    private EditText nameEt;
    private RadioGroup sexRg;
    private RadioButton maleRb;
    private RadioButton femaleRb;
    private Button editConfirmBt;
    private Button editCancelBt;

    public void onCreate(Bundle savedInstanceStste) {
        super.onCreate(savedInstanceStste);
        setContentView(R.layout.student_edit);
        noEt = findViewById(R.id.noEt);
        nameEt = findViewById(R.id.nameEt);
        //sexRg = findViewById(R.id.sexRg);
        maleRb = findViewById(R.id.maleRb);
        femaleRb = findViewById(R.id.femaleRb);
        editConfirmBt = findViewById(R.id.editConfirm);
        editCancelBt = findViewById(R.id.editCancel);

        Toast.makeText(this,"Edit Student",Toast.LENGTH_SHORT);

        Intent editI = getIntent();
        String no = editI.getStringExtra("no");
        String name = editI.getStringExtra("name");
        boolean sex = editI.getBooleanExtra("sex",false);


        noEt.setText(no);
        nameEt.setText(name);
        if(sex)
            femaleRb.setChecked(true);
        else maleRb.setChecked(true);

        editConfirmBt.setOnClickListener(this);
        editCancelBt.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.editConfirm:
                String no = noEt.getText().toString();
                String name = nameEt.getText().toString();
                boolean sex;
                if(maleRb.isChecked())
                    sex = false;
                else sex = true;
                Intent data = new Intent();
                data.putExtra("no",no);
                data.putExtra("name",name);
                data.putExtra("sex",sex);
                setResult(1,data);
                finish();
                break;
            case R.id.editCancel:
                setResult(2);
                finish();
                break;
        }

    }
}
