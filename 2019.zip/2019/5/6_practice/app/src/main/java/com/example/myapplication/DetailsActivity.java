package com.example.myapplication;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;


import com.j256.ormlite.dao.CloseableIterator;
import com.j256.ormlite.dao.CloseableWrappedIterable;
import com.j256.ormlite.dao.Dao;
import com.j256.ormlite.dao.DatabaseResultsMapper;
import com.j256.ormlite.dao.ForeignCollection;
import com.j256.ormlite.dao.GenericRawResults;
import com.j256.ormlite.dao.ObjectCache;
import com.j256.ormlite.dao.RawRowMapper;
import com.j256.ormlite.dao.RawRowObjectMapper;
import com.j256.ormlite.field.DataType;
import com.j256.ormlite.field.FieldType;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.GenericRowMapper;
import com.j256.ormlite.stmt.PreparedDelete;
import com.j256.ormlite.stmt.PreparedQuery;
import com.j256.ormlite.stmt.PreparedUpdate;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.UpdateBuilder;
import com.j256.ormlite.support.ConnectionSource;
import com.j256.ormlite.support.DatabaseConnection;
import com.j256.ormlite.support.DatabaseResults;
import com.j256.ormlite.table.ObjectFactory;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;

import static com.example.myapplication.R.mipmap.miku;

public class DetailsActivity extends AppCompatActivity implements View.OnClickListener{
    private ImageView deIv;
    private TextView deNoTv;
    private TextView deNameTv;
    private TextView deSexTv;
    private Button changeImageBt;
    private Button insertIntoDbBt;
    Intent De;
    private int id;
    //private ScrollView deSv;
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_details);
        initView();
        De = getIntent();
        id = De.getIntExtra("id",1);
        switch(id){
            case 1:
                deIv.setImageResource(miku);
                break;
            case 2:
                deIv.setImageResource(R.mipmap.hzh);
                break;
            case 3:
                deIv.setImageResource(R.mipmap.yby);
                break;
                default:
                    deIv.setImageResource(miku);
        }
        deNoTv.setText(De.getStringExtra("no"));
        deNameTv.setText(De.getStringExtra("name"));
        if(De.getBooleanExtra("sex",true))
            deSexTv.setText("女");
        else deSexTv.setText("男");
        insertIntoDbBt.setOnClickListener(this);


    }
    public void initView(){

        //deSv = findViewById(R.id.deSv);
        deIv = findViewById(R.id.detailIv);
        //deSv.setVerticalScrollBarEnabled(false);
        deNoTv = findViewById(R.id.deNoTv);
        deNameTv = findViewById(R.id.deNameTv);
        deSexTv = findViewById(R.id.deSexTv);
        changeImageBt = findViewById(R.id.changeImageBt);
        insertIntoDbBt = findViewById(R.id.insertIntoDbBt);
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.insertIntoDbBt:
                DbHelper helper = new DbHelper(this);
                try {
                    Student s = new Student(id,De.getStringExtra("no"),De.getStringExtra("name"),De.getBooleanExtra("sex",true));
                    Dao<Student,Integer> sdao = helper.getDao(Student.class);

                    Student s0 = new Student();
                    //sdao.create(s0);

                    sdao.create(s);
                    //sdao.delete(s0);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                break;

        }


    }
}
