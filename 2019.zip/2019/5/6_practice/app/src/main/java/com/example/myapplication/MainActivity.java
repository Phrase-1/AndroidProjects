package com.example.myapplication;

import android.content.Intent;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemClickListener, View.OnClickListener,View.OnLongClickListener, AdapterView.OnItemLongClickListener {

    private ArrayList<Student> data;
    private ArrayList<Student> selectedList = new ArrayList<>();
    private StudentAdapter ad;
    private Student selectedStudent = null;
    private ListView lv;
    private Button editBt;
    private Button addBt;
    private Button delBt;
    private EditText searchEt;
    private Button searchBt;



    // private AdapterView onLongItemClick;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        initView();
        data = new ArrayList<>();
        Student[] ss = new Student[4];
        ss[0] = new Student(1, "1","miku",true);
        ss[1] = new Student(2,"2","韩泽浩",false);
        ss[2] = new Student(3,"3","闫博远",true);
        ss[3] = new Student(4,"4","王文炜",false);
        for(Student s : ss)
            data.add(s);
        ad = new StudentAdapter(data,this);
        lv.setAdapter(ad);
        lv.setOnItemClickListener(this );
        lv.setOnItemLongClickListener(this);

        editBt.setOnClickListener(this);
        addBt.setOnClickListener(this);
        delBt.setOnClickListener(this);
        searchBt.setOnClickListener(this);



    }
    public void initView(){
        lv = findViewById(R.id.lv);
        editBt = findViewById(R.id.editBt);
        addBt = findViewById(R.id.addBt);
        delBt = findViewById(R.id.delBt);
        searchEt = findViewById(R.id.searchEt);
        searchBt = findViewById(R.id.searchBt);
    }


    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Student s = data.get(position);
        Intent De = new Intent();
        De.putExtra("id",s.getId());
        De.putExtra("no",s.getNo());
        De.putExtra("name",s.getName());
        De.putExtra("sex",s.isSex());
        De.setClass(MainActivity.this,DetailsActivity.class);
        startActivity(De);
    }
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        if(selectedStudent == null){
            Student s = data.get(position);
            s.setSelected(true);
            selectedStudent = s;
        }else{
            if(selectedStudent == data.get(position)){
                selectedStudent.setSelected(false);
                selectedStudent = null;
            }
            else {
                selectedStudent.setSelected(false);
                Student s = data.get(position);
                s.setSelected(true);
                selectedStudent = s;
            }
        }
        ad.notifyDataSetChanged();
        return true;
    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.editBt:
                if(selectedStudent == null){
                    Toast.makeText(this,"please select a student",Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent editI = new Intent();
                editI.putExtra("id",selectedStudent.getId());
                editI.putExtra("no",selectedStudent.getNo());
                editI.putExtra("name",selectedStudent.getName());
                editI.putExtra("sex",selectedStudent.isSex());
                editI.setClass(this,EditActivity.class);
                startActivityForResult(editI,1);
                break;
            case R.id.addBt:
                Intent addI = new Intent();
                addI.setClass(this,EditActivity.class);
                startActivityForResult(addI,2);
                break;
            case R.id.delBt:
                if(selectedStudent == null){
                    Toast.makeText(this,"please select a student",Toast.LENGTH_SHORT).show();
                    return;
                }
                data.remove(selectedStudent);
                selectedStudent = null;
                ad.notifyDataSetChanged();
                break;
            case R.id.searchBt:
                if(!TextUtils.isEmpty(searchEt.getText())){
                    Intent searchI = new Intent();
                    searchI.putExtra("keyword",searchEt.getText());
                    searchI.setClass(this,SearchActivity.class);
                    startActivity(searchI);

                }
                else{
                    Toast.makeText(this,"please input the search content",Toast.LENGTH_SHORT).show();
                }



        }

    }

    @Override
    public boolean onLongClick(View v) {
        return true;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch(requestCode){
            case 1:
                if(resultCode == 1){
                    String no = data.getStringExtra("no");
                    String name = data.getStringExtra("name");
                    boolean sex = data.getBooleanExtra("sex",true);

                    selectedStudent.setNo(no);
                    selectedStudent.setName(name);
                    selectedStudent.setSex(sex);

                    ad.notifyDataSetChanged();

                }
                break;
            case 2:
                if(resultCode == 1){
                    String no = data.getStringExtra("no");
                    String name = data.getStringExtra("name");
                    boolean sex = data.getBooleanExtra("sex",true);
                    Student s = new Student(this.data.size()+1,no,name,sex);
                    this.data.add(s);
                    ad.notifyDataSetChanged();
                }
                break;

        }

    }


}
