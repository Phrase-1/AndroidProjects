package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;

import com.j256.ormlite.dao.Dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity {

    private ArrayList<Student> dataS;
    private StudentAdapter adS;
    private Intent searchI;
    private ListView lvS;
    private DbHelper helper;
    private Dao sdao;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.student_search);
        initView();
        try {
            dataS = (ArrayList<Student>) sdao.queryForAll();

            //List<Student> list = sdao.queryForAll();
            if(dataS.size()== 0){
                Toast.makeText(this,"list为空",Toast.LENGTH_SHORT).show();
            }
            else{
                Toast.makeText(this,"list="+String.valueOf(dataS.size()),Toast.LENGTH_SHORT).show();
            }
            adS = new StudentAdapter(dataS,this);
            lvS.setAdapter(adS);
            //adS.notifyDataSetChanged();
        } catch (SQLException e) {
            e.printStackTrace();
        }


    }


    public void initView(){
        //dataS = new ArrayList<>();

        searchI = getIntent();
        lvS = findViewById(R.id.lvS);
        lvS.setAdapter(adS);
        helper = new DbHelper(this);
        try {
            sdao = helper.getDao(Student.class);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
