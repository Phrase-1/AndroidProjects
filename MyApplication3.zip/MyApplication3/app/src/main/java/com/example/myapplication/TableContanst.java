package com.example.myapplication;

public final class TableContanst {
    public static final String STUDENT_TABLE = "supply";
    public static final class SupplyColumns {
        public static final String ID = "_id";
        public static final String NAME = "name";
        public static final String AGE = "number";
        public static final String SEX = "attribute";
        public static final String LIKES = "conditions";
        public static final String PHONE_NUMBER = "phone_number";
        public static final String TRAIN_DATE = "use_date";
        public static final String MODIFY_TIME = "modify_time";
    }
}